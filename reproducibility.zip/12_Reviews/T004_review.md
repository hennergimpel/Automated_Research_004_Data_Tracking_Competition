# T004 independent contribution, model and central-proof review

**Decision: PASS for contribution/model/feasibility acceptance, within the scope below. This is not submission-readiness acceptance.**

Reviewer: `gao-independent-R04-R06-T004-20261022`; producer: `gao-contribution-model-T004`. Requested execution: Codex, gpt-6-astra/high, following the recorded escalation. Actual model and effort: **unknown**. The original task and its snapshots were retained. This review did not edit producer artifacts or shared state, delegate work, acquire new literature, or conduct a search-completeness audit.

## Accepted scope and contribution judgment

The accepted result is a strict, open-set existence result for a related architecture-before-price game: with binary app architecture, sufficiently strong app personalization benefits, positive complementary privacy exposure across controllers, fixed platform targeting technology, and the stated compact price domain, platform exemption can yield low tracking as a strictly dominant architecture whereas permitting users to refuse platform targeting yields high tracking as strictly dominant. Price continuations are unique among pure equilibria on that domain. This is not uniqueness among arbitrary mixed price continuations, an equilibrium of continuous tracking choices, a welfare result, an optimal policy result, or a replication/nesting of Gao's complete game.

The contribution is narrow but substantively defensible relative to the closest read originals. The important object is a developer's architecture changing permission to its **competing platform advertising outlet**, thereby changing both its per-user advertising opportunity and the composition of its price-sensitive audience. The positive privacy interaction is assumed, not established empirically or derived from information technology. The result therefore identifies an implication of this interaction; it does not establish that giving control generally raises tracking. Binary architecture itself and the familiar commission/first-impression mechanisms are not contributions.

This judgment is grounded in the following original-source contexts:

* Gopal et al., input `022_GHH23.md`, PDF pp.15–18, Section 3.2/Lemma 2, and pp.20–21, Proposition 1: consent, lower prices and increased default third-party data sharing already coexist. The new paper must acknowledge this directly. The additional object here is architecture-dependent refusal of the developer's rival platform advertiser; it is not the generic consent paradox or user choice among a website's third parties.
* Johnson, Jungbauer and Preuss, input `026_JJP24.md`, PDF pp.13–16, Section 2/Propositions 2–4: opt-out alters sharing and cross-targeting through the relative value of targetable website and look-alike audiences. That already supplies a consent externality. Here the platform-permission rate responds to an app design and enters subsequent app price competition, rather than being the exogenous tracking fraction of that source.
* Zhang et al., input `032_ZKRW26.md`, PDF pp.13–16, targeting/price and platform-revenue arguments: targeting, seller competition and commission revenue are established subjects. No welfare-sign claim from that preprint is needed or accepted.
* Casadesus-Masanell and Hervas-Drane, input `017_CH15.md`, PDF pp.9–10, Section 2: committed disclosure before prices and endogenous information provision are established. The proposed timing is economically recognizable, while neither timing nor price/privacy competition alone is novel.

The Gal-Or et al. (2018) fulltext gap remains an explicit boundary. I make no claim about its exact model or about priority over all platform/privacy-control models. Its missing mechanism is not required for the bounded comparison and result accepted here. Do not turn this acceptance into a first-in-literature claim. No targeted additional acquisition was necessary for this judgment.

## Independent derivation from the primitives

For each app, the incremental utility of app permission, holding platform permission fixed, is `B-lambda*t-kappa*t*phi_S`. The strict lower bound `B-(lambda+kappa)*t_H>0` makes app permission optimal for every type. Under joint permission, platform permission is therefore chosen exactly when `z>=kappa*t`. Thus the optimized nonprice utility is `B-lambda*t+max(0,z-kappa*t)`; under exemption it is `B-(lambda+kappa)*t+z`. These expressions are continuous and piecewise affine in z, and the participation inequality guarantees that an app dominates platform-only use at every history in the specified price domain.

Equating the two app utilities gives the stated clipped Hotelling demand. Enumerating first successful impressions gives app margin `r_i=xi*t_i[1-(1-f)*s*b_i]` and platform advertising margin `xi*s*b_i(1-f*t_i)`. The user permission event is endogenous and cannot be multiplied by an unconditional half-market audience when architectures differ.

With all type shares interior, define `delta=w_i-w_j`, `W=E[delta]`, `R_i=E[r_i]`. Differentiating integrated profit holding the rival price fixed gives

`2*p_i-p_j=tau+W-R_i/k`.

Solving the two linear equations gives the producer's conditional prices. With `DeltaH=W+(R_i-R_j)/k`, the demand is `D_i=1/2+DeltaH/(6*tau)`. At the optimum, `k*p_i+R_i=2*k*tau*D_i`, so profit can be written directly as

`pi_i=2*k*tau*D_i^2+Cov(r_i,delta)/(2*tau)`.

This yields the displayed expansion and explains why the covariance cannot be discarded. Splitting z at `kappa*l` and `kappa*h` reproduces both covariance formulas. In particular, for H against L the utility difference is constant below `kappa*l`, declines linearly between the thresholds, and is constant above `kappa*h`; the high app earns its larger advertising margin precisely below its platform-permission threshold. This gives positive high-app covariance. The corresponding low-app covariance is negative. Independent exact integration produces `33/3125` and `-33/12500`, respectively, at the example.

The independent implementation in `T004_independent/check.py` enumerates permission bundles from utility, integrates clipped affine demand by exact trapezoids, solves the price equations, and calculates profits and platform audiences. It imports and executes no producer module. All eight profiles agree exactly with the frozen results for prices, demand, app profits, platform profits, permission audience, mean advertising margins, mean utility differences and covariances. The final parameter is `xi=11/20`; exploratory `xi=1` is not used.

## Global prices, corners, architecture deviations and robustness

The sufficient price-uniqueness lemma is valid on the stated domain. For `d=(lambda+kappa)(h-l)`, `|delta(z)|<=d`. Below `p_j-tau+d`, demand is at least `1-d/tau`; the given positive derivative bound applies even when some types are fully captured. Above `p_j+tau-d`, no type is fully captured and every active share is at most `d/tau`. Since `p_i>=tau-d>2*d`, each active type contributes a negative derivative. A zero-demand price cannot maximize because a positive-profit alternative exists. The strict inequalities also exclude the clipping boundaries using the appropriate one-sided derivatives. Every best response therefore lies in the all-interior region, where the objective is strictly concave. Its unconstrained optimizer is strictly inside `[0,P]`; best replies have slope one-half and a unique intersection.

At the example the relevant strict slacks are: `tau-3*d=13/20`, low-region derivative bound `363/1600`, lower price bound `331/640`, upper-price slack `11/40`, app-permission slack `13/40`, and participation slack `213/40`. All are positive. This proves pure price-continuation uniqueness for all four architecture profiles under both policies, not merely local optimality at the reported prices.

I also independently checked the eight frozen Bernstein certificates. The checker establishes contiguous interval coverage from zero to the exact zero-demand threshold, absence of a structural demand breakpoint in each segment's interior, equality of the claimed cubic and independently integrated profit gap, and nonnegativity of every Bernstein coefficient. On a structural interval, moving saturation limits are affine in price; integrating affine demand makes audience at most quadratic and multiplying by the affine margin makes profit at most cubic. Consequently equality at four distinct rational arguments establishes the polynomial identity; this is not a finite price-grid inference. The tail has zero demand. The rival's candidate price ensures participation for all consumers even if the deviating own price exceeds P, so these unbounded unilateral-deviation checks also use the correct outside option. They do not establish unbounded-domain equilibrium uniqueness.

Symmetric-architecture developer profit is `k*tau/2=4/5`. The independently verified architecture deviation gains are:

| Policy | High against low, versus LL | Low against high, versus HH |
|---|---:|---:|
| Exempt platform | `-8151/128000` | `8489/128000` |
| Joint permission | `30897/3200000` | `-24463/3200000` |

These strict signs exhaust the binary architecture deviations and imply the stated dominance and equilibrium contrast with pure price continuations. The primitives, prices, finite-profile profits and the sufficient inequalities are continuous around the rational witness; the permission thresholds remain strictly inside the support. A nonempty open neighborhood follows without a numerical grid or an explicitly maximal interval. The existing proof and exact existence evidence already suffice for this scope.

## Constant-reach diagnostic: useful but not a policy equilibrium

The distinction from a mere fixed reduction in platform targeting is supported. Independent integration gives `DeltaH_J=21/800`, while the fit preserving the actual mean utility difference and using `qmid=3/5` gives `-23/800`. The omitted advertising-margin term is `xi*a*kappa*(h^2-l^2)/(2*k*L)`, and the actual model additionally contains the sorting covariance. This shows that the endogenous controller-permission response matters for the architecture incentive at the witness; merely matching average utility and a fixed targeting reduction misses its direction.

Drafting clarification: `qmid` is the **arithmetic mean of the two architecture-specific marginal permission rates**, not the realized platform audience in the asymmetric equilibrium. The latter is `4761/8000=0.595125`, owing to sorting. This is not a failure of the producer's accurately defined comparator. To remove possible ambiguity, I additionally matched this realized aggregate reach: the fixed-reach index is still negative, `-17971/640000`, whereas the actual index is positive. These are diagnostic fits, not separately feasible rational-consent policy counterfactuals. They cannot establish that every exogenous-consent model or every capacity calibration fails, and the manuscript must not call them that.

## Seed benchmark and timing discrepancy

I visually inspected the frozen original-page renders corresponding to journal pp.1603, 1604, 1606 and 1621. The central original regions confirm the utility/permission and first-impression expressions, Figure 3's simultaneous developer price/tracking decisions, and the Appendix's substitution of both conditional equilibrium prices before deriving tracking. The reconstruction of the relevant interior opt-out region is faithful.

From the two consumer groups' utilities, holding both rival choices fixed, the symmetric simultaneous-choice conditions are

`k*p=k*tau-r*(1-alpha)*t`,

`r*tau-k*lambda*p-r*lambda*t=0`.

Substituting the reported Lemma 2 pair into the own-tracking derivative gives `(1-alpha)*(r-k*lambda)/6`, as claimed. In the supplied witness the reported pair is `(t,p)=(4/15,5/6)`, and the derivative is `1/60`. My independent utility-based calculation gives a profit gain of exactly `17/120000` for raising only own tracking by `1/100`. The low-type share becomes `99/200`, the high-type share remains `1/2`, the tracking bounds and both permission inequalities remain strict, the price-positive domain threshold is `lambda_hat=1/2<lambda=1`, and coverage has slack. This is a valid same-regime unilateral deviation in the displayed simultaneous-choice continuation.

The discrepancy is thus independently supported, rather than inherited as an assumption. Its reach is limited: it diagnoses a mismatch between the displayed simultaneous timing and the reported conditional formula. It does not prove the paper's overall qualitative claims false, reconstruct all its equilibria, or establish the global validity of an alternative sequential interpretation. The new related game's result does not use the disputed equilibrium and explicitly changes timing, heterogeneity and architecture choices.

**Retain this diagnostic in research notes only.** The manuscript can accurately state its own sequence and the inherited primitives without a published-paper-error allegation. If a later manuscript makes such an allegation, that new central claim requires additional targeted original-source treatment; it is not authorized by the present narrow paper scope. No further seed investigation is required to draft the accepted result.

## Acceptance criteria and next work

All five original task criteria pass. The model fits the stated narrow question, the relevant seed primitives have been inspected and rederived, the result has global deviation support rather than finite numerics, and the contribution and exclusions are concrete enough for an eight-page main paper. This acceptance does not extend to all possible policy effects or literature priority.

No new central derivation, second independent review of the unchanged result, mixed-equilibrium analysis, continuous-tracking extension, or general robustness campaign is needed before drafting. The remaining work is bounded theorem and manuscript preparation:

1. Package the accepted permission solution, conditional price lemma and strict open-set architecture proposition with explicit assumptions and proof links; retain the compact-domain and pure-continuation qualifications.
2. State the assumed cross-controller privacy complementarity prominently and explain that app permission remains universal in the established domain. Present the two policy arms separately from the fixed-reach diagnostic and distinguish marginal mean permission from realized reach.
3. Position the result against the consent/sharing findings already in Gopal and Johnson and the established targeting/commission mechanism. Avoid priority claims unsupported by the Gal-Or fulltext gap.
4. Keep the seed timing diagnostic out of the substantive manuscript claim. Preserve the research-note evidence and failed alternatives for the workflow record.
5. Include explicit limitations and avoid welfare/regulatory or voluntary-platform-adoption conclusions. The witness's platform profit falls; its developers' symmetric equilibrium profits remain equal even though architecture and prices change.

An explicit robustness interval could be added if it earns its page cost, but is optional: strict inequalities already prove local robustness. A later substantive model change or broader claim would reopen only the affected central issue. No user action is required; R00 owns transition and shared-state updates.

Evidence artifacts: `12_Reviews/T004_independent/check.py`, `12_Reviews/T004_independent/results.json`, the six frozen task outputs, the frozen central source renders and certificates listed in `12_Reviews/T004_frozen_evidence/manifest.json`, and the original-source contexts identified above. Execution and hashes are recorded in `T004_review.json`. Authoritative per-invocation token usage is unavailable and is recorded as unknown rather than estimated.
