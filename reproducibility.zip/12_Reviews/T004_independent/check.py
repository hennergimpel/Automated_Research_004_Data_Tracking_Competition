"""Independent R04/R06 exact calculation from consumer permission utilities.
No producer module is imported or executed. Standard library, deterministic.
Certifications use exact trapezoid integration on affine-utility pieces and
verify each supplied Bernstein polynomial identity at four distinct arguments.
"""
from fractions import Fraction as F
from pathlib import Path
from math import comb
import json, platform, sys

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
tau,k,xi,s,f,kap,lam,L,B,v,P=map(F,['2','4/5','11/20','4/5','1/2','4/5','1/10','1','1','10','3'])
design={'L':F(1,4),'H':F(3,4)}

def utility(t,z,app_permission,platform_permission):
    return (B-lam*t)*app_permission+z*platform_permission-kap*t*app_permission*platform_permission

def bundle(t,z,mode):
    choices=[(utility(t,z,a,b),a,b) for a in (0,1) for b in ((1,) if mode=='E' else (0,1))]
    return max(choices)

def pieces(t,u,mode):
    cuts=sorted({F(0),L,kap*t,kap*u})
    for left,right in zip(cuts,cuts[1:]):
        _,a,b=bundle(t,(left+right)/2,mode)
        _,aj,bj=bundle(u,(left+right)/2,mode)
        assert a==aj==1
        # Difference in optimized nonprice utilities is affine on this piece.
        dl=utility(t,left,a,b)-utility(u,left,aj,bj)
        dr=utility(t,right,a,b)-utility(u,right,aj,bj)
        yield left,right,dl,dr,xi*t*a*(1-(1-f)*s*b),xi*u*aj*(1-(1-f)*s*bj),b,bj

def integrate(t,u,mode,pi,pj):
    demand=profit=plat=permission=F(0)
    for left,right,dl,dr,r,rj,b,bj in pieces(t,u,mode):
        # Intersect the affine demand with both horizontal clipping lines.
        y0=(tau+pj-pi+dl)/(2*tau)
        y1=(tau+pj-pi+dr)/(2*tau)
        knots=[F(0),F(1)]
        if y0!=y1:
            knots += [(level-y0)/(y1-y0) for level in (0,1) if 0<(level-y0)/(y1-y0)<1]
        knots=sorted(knots)
        mass=sum((q-p)*(min(F(1),max(F(0),y0+(y1-y0)*p))+min(F(1),max(F(0),y0+(y1-y0)*q)))/2 for p,q in zip(knots,knots[1:]))*(right-left)/L
        other=(right-left)/L-mass
        demand+=mass
        profit+=(k*pi+r)*mass
        plat+=xi*s*(b*(1-f*t)*mass+bj*(1-f*u)*other)+(1-k)*(pi*mass+pj*other)
        permission+=b*mass+bj*other
    return demand,profit,plat,permission

def solve(t,u,mode):
    dw=ri=rj=covraw=F(0)
    for left,right,dl,dr,r,r_other,*_ in pieces(t,u,mode):
        m=(right-left)/L
        dw+=m*(dl+dr)/2
        ri+=m*r
        rj+=m*r_other
        covraw+=m*r*(dl+dr)/2
    # FOC: 2pi-pj=tau+E(delta)-E(r_i)/k, and the rival equation.
    ai=tau+dw-ri/k
    aj=tau-dw-rj/k
    pi=(2*ai+aj)/3
    pj=(ai+2*aj)/3
    D,profit,plat,q=integrate(t,u,mode,pi,pj)
    cov=covraw-ri*dw
    dh=dw+(ri-rj)/k
    assert D==F(1,2)+dh/(6*tau)
    assert profit==2*k*tau*D*D+cov/(2*tau)
    return dict(p=pi,pj=pj,D=D,profit=profit,platform=plat,q=q,R=ri,Wdiff=dw,covariance=cov,competitive_index=dh)

def unbox(x):
    if isinstance(x,dict) and 'exact' in x:return F(x['exact'])
    return x

frozen=json.loads((ROOT/'03_Tasks/T004_contribution_model/outputs/004_T004_results.json').read_text())
certs=json.loads((ROOT/'12_Reviews/T004_frozen_evidence/price_certificates.json').read_text())
out={'runtime':sys.version,'platform':platform.platform(),'precision':'exact rational','producer_imports':False,'games':{},'certificate_checks':{}}
for mode in ('E','J'):
    for own in ('L','H'):
        for rival in ('L','H'):
            profile=own+rival
            t,u=design[own],design[rival]
            sol=solve(t,u,mode)
            out['games'][mode+profile]=sol
            for field in ('p','pj','D','profit','platform','q','R','Wdiff','covariance'):
                assert sol[field]==unbox(frozen['games'][mode][profile][field]),(mode,profile,field)
            c=certs[mode+profile]
            upper=unbox(c['price_upper_zero_demand'])
            # All demand-support changes occur when an endpoint reaches share 0 or 1.
            structural=set()
            for left,right,dl,dr,*_ in pieces(t,u,mode):
                for delta in (dl,dr):
                    for x in (sol['pj']+tau+delta,sol['pj']-tau+delta):
                        if 0<x<upper:structural.add(x)
            last=F(0)
            for seg in c['segments']:
                lo,hi=unbox(seg['lo']),unbox(seg['hi'])
                coeff=list(map(unbox,seg['bernstein_coefficients']))
                assert lo==last and lo<hi and all(b>=0 for b in coeff)
                assert not any(lo<b<hi for b in structural)
                for x in (F(0),F(1,3),F(2,3),F(1)):
                    bpoly=sum(coeff[j]*comb(3,j)*x**j*(1-x)**(3-j) for j in range(4))
                    actual=sol['profit']-integrate(t,u,mode,lo+(hi-lo)*x,sol['pj'])[1]
                    assert bpoly==actual,(mode,profile,lo,hi,x,bpoly,actual)
                last=hi
            assert last==upper
            assert integrate(t,u,mode,upper,sol['pj'])[0]==0
            assert upper==max(sol['pj']+tau+delta for _,_,dl,dr,*_ in pieces(t,u,mode) for delta in (dl,dr))
            out['certificate_checks'][mode+profile]={'segments':len(c['segments']),'complete_cover':True,'cubic_identities_verified':True,'nonnegative_coefficients':True,'zero_demand_threshold':upper}

base=k*tau/2
out['architecture_gains']={m:{'high_against_low':out['games'][m+'HL']['profit']-base,'low_against_high':out['games'][m+'LH']['profit']-base} for m in ('E','J')}
assert out['architecture_gains']['E']['high_against_low']<0<out['architecture_gains']['E']['low_against_high']
assert out['architecture_gains']['J']['low_against_high']<0<out['architecture_gains']['J']['high_against_low']
d=(lam+kap)*(design['H']-design['L'])
out['strict_slacks']={'tau_minus_3d':tau-3*d,'low_derivative':k*(1-d/tau)-(k*max(F(0),P-tau+d)+xi*design['H'])/(2*tau),'best_reply_lower':(tau-d-xi*design['H']/k)/2,'P_minus_best_reply_upper':P-(tau+P+d)/2,'app_permission':B-(lam+kap)*design['H'],'coverage':v-P-tau+B-(lam+kap)*design['H']}
assert all(x>0 for x in out['strict_slacks'].values())
qmid=1-kap*(design['H']+design['L'])/(2*L)
fit=lambda q:out['games']['JHL']['Wdiff']+xi*(design['H']-design['L'])*(1-(1-f)*s*q)/k
out['fit']={'arithmetic_qmid':qmid,'actual_profile_platform_permission':out['games']['JHL']['q'],'fitted_index_at_qmid':fit(qmid),'fitted_index_at_actual_aggregate_reach':fit(out['games']['JHL']['q']),'actual_index':out['games']['JHL']['competitive_index']}
assert out['fit']['fitted_index_at_actual_aggregate_reach']<0<out['fit']['actual_index']

# Seed derivation, from the two privacy groups' Hotelling choices.
alpha,ll,lh,beta,sk,stau,r=map(F,['1/2','1','2','2/5','4/5','1','1'])
t0=2*stau*(1/ll-sk/r)/(3*alpha)
p0=stau-r*(1-alpha)*t0/sk
def seed_profit(t):
    Dl=(stau+max(F(0),beta-ll*t)-max(F(0),beta-ll*t0))/(2*stau)
    Dh=(stau+max(F(0),beta-lh*t)-max(F(0),beta-lh*t0))/(2*stau)
    return sk*p0*((1-alpha)*Dl+alpha*Dh)+r*t*(1-alpha)*Dl
eps=F(1,100)
assert ll*(t0+eps)<beta<lh*t0 and 0<t0<t0+eps<1
deriv=(1-alpha)*(r*stau-sk*ll*p0-r*ll*t0)/(2*stau)
gain=seed_profit(t0+eps)-seed_profit(t0)
assert deriv==F(1,60) and gain==F(17,120000)
out['seed']={'reported_tracking':t0,'reported_price':p0,'derivative':deriv,'epsilon':eps,'profit_gain':gain,'low_type_share_after':F(99,200),'high_type_share_after':F(1,2),'price_positive_domain_lambda_threshold':2*(1-alpha)*r/((2+alpha)*sk),'coverage_lower_bound':F(3)-stau-p0}

def encode(x):
    if isinstance(x,F):return {'exact':str(x),'decimal':float(x)}
    raise TypeError(type(x))
(OUT/'results.json').write_text(json.dumps(out,default=encode,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_eight_profiles_agree':True,'all_eight_certificates_verified':True,'architecture_gains':out['architecture_gains'],'fit':out['fit'],'seed':out['seed']},default=encode,indent=2))
