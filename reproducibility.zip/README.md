# Platform Permission and App Tracking: reproducible research package

This is a local prepared artifact, not evidence of public release, author approval or submission. The paper presents an exact existence result in a related architecture-before-price game. It assumes positive cross-controller privacy exposure, two app designs and strong app benefits. Platform permission may change the dominant design; no general tracking, welfare or policy-optimality claim is made.

## Reproduce the mathematics

Extract the ZIP into an empty directory. With Python 3.11 or later, run:

```text
python reproduce.py
```

No packages, network access, data download, API account or paid tool is needed for this run. It checks the SHA-256 manifest, runs the original exact-rational producer program, then the original independent checker. The checker imports no producer module. It checks all eight profiles and global piecewise cubic price-deviation certificates. Exact scientific fields are compared with retained originals; machine/Python metadata may differ. No random numbers or floating-point tolerances are used. The output is `reproduction_report.json`.

The first run overwrites generated results inside the extracted copy. Original expected results remain in `03_Tasks/T004_contribution_model/outputs` and `provenance/original_independent_results.json`. To rerun the manifest-first command, extract a fresh copy. This preserves original project science and the manifest's meaning.

## Contents and provenance

- `07_Study`: original model and benchmark research notes, including the bounded seed timing diagnostic.
- `06_Concept`: original contribution decision and rejected alternatives.
- `10_Analysis`: unchanged producer code, exact results, certificates, Wolfram code and original remote receipt.
- `12_Reviews`: independent original code/results, frozen certificate input and subsequent scientific review. Historical producer labels remain provisional in their original bytes; the later review supplies the acceptance record. It is not a final manuscript review.
- `11_Manuscript`: manuscript, final process account, editable-document builder and bounded Word export helper.
- `13_Export`: prepared editable Word document, PDF and submission text.
- `provenance`: source/claim/version map, selective path-redacted receipt, original independent results, and this package's production reproduction receipt when available.
- `MANIFEST.json`: file paths, sizes and SHA-256 hashes; the manifest does not hash itself.

Third-party reading PDFs, credentials, raw provider transcripts and personal absolute paths are excluded. Nine distinct sources are used substantively; four are in the user-specified IS journals. The source map identifies the locally inspected versions and published successors. It supplies acquisition/DOI links without claiming that the reading PDFs are redistributable.

## Optional document rebuild

The delivered DOCX/PDF can be read without rebuilding. To rebuild DOCX, install Python with lxml and Pandoc 3.2, obtain the official ICIS 2026 Word template from the venue's template resource, and verify template SHA-256 `ae00895dd26ad1ae55c6bdbd578d8233136bd38b496f810bed5b02ff47d3e7b5`. The third-party template is not redistributed here. From the extracted root run:

```text
python 11_Manuscript/T006_build.py --pandoc PATH_TO_PANDOC --template PATH_TO_OFFICIAL_TEMPLATE
powershell -File 11_Manuscript/T006_support/export_word.ps1 -Docx 13_Export/paper.docx -Pdf 13_Export/paper.pdf
```

Microsoft Word is required for this optional PDF route; it is not required for analysis reproduction. The helper opens a dedicated read-only document, disables macros and closes only that document/instance. Poppler can render each final PDF page for visual inspection. The build preserves official styles/section geometry and produces editable Office Math. A body abstract is an explicitly recorded user-directed departure from the historical template omission instruction. Machine/font/rendering differences can change pagination, so every rebuilt page needs inspection.

## Symbolic checks and interpretation

`10_Analysis/T004_checks.wl` is the original stateless Wolfram code. Its preserved receipt records the earlier remote kernel version and results, including the failed context call. No Wolfram call was made during manuscript packaging. The standard-library reproduction verifies the exact central numerical/certificate evidence independently of that service. The seed diagnostic remains a research-note item; the manuscript makes no published-error allegation. Fixed-reach fits are diagnostics, not alternative optimizing-user policy equilibria.
