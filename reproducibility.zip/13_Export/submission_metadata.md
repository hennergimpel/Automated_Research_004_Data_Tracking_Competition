# Prepared Submission Text

Prepared locally for the ICIS 2026 PDW on Autonomous Scholarship. This is editable submission text, not a portal form, author declaration, approval or submission receipt. The manuscript is anonymous pending separate author metadata.

## Title

Platform Permission and App Tracking: Advertising Competition with Complementary Privacy Exposure

## Abstract

Can extending permission to a platform's own targeting change the tracking architectures chosen by competing app developers? We study an architecture-then-price game in which users choose an app and separate data permissions. The model assumes an additional privacy loss when both controllers use data. Strong app personalization benefits preserve app permission, while a more intensive app design induces some users to refuse the competing platform advertiser. We derive permission choices and price continuations and establish a strict existence result: platform exemption supports low tracking as a dominant architecture, whereas separate platform permission supports high tracking, on a nonempty open set of primitives. Matching aggregate platform reach with a constant targeting reduction misses the direction of the competitive index at the example. The contribution identifies a controller-specific audience response in platform governance; it does not establish a general tracking, welfare or optimal-policy effect.

## Keywords

Platform governance; privacy permission; advertising competition; app tracking; game theory; complementary privacy exposure.

## Research Method and Contribution

Formal game-theoretic modeling with exact-rational computational evidence. The paper relates technical app architecture to controller-specific permission scope and user choices. A self-contained permission proposition, global pure-price continuation lemma and strict open-set existence proposition establish the narrow architecture contrast. It is a related game building on Gao, Gu and Liu (2025), not a replication or nesting of their complete model. Nine scholarly works are substantively cited, four in the user-specified IS journals. The result assumes two available architectures, high app benefits, positive cross-controller privacy exposure and fixed platform technology; it does not establish welfare, optimal policy, mixed-price uniqueness or voluntary platform adoption.

## Human–AI Contribution Statement

The human commissioned autonomous paper development, supplied and confirmed the seed article, specified the venue and scope, authorized Undermind and Wolfram, and supplied inherited workflow and manuscript requirements. The available records contain no human-supplied mechanism, derivation, result or scientific evaluation. Codex agents performed candidate formulation and rejection, literature comparison, model design, derivations, exact-rational and symbolic calculations, interpretation, scientific writing, artifact production and a fresh independent agent review of the central contribution/model/result. Independent agent review is not human scientific review. The manuscript's new claims and interpretations remain subject to the separate final scientific review process at this production cutoff. No human author review or approval is claimed.

Requested routing used GPT-6.1 Sol/medium for setup and process writing, Sol/high for literature and manuscript production, GPT-6 Luna/medium for template preparation, and GPT-6 Astra/high for theory and the fresh central scientific review. Actual provider/model versions, actual effort and authoritative per-invocation token totals were not exposed and are unknown. Agents used a local Windows workspace, with Undermind and Wolfram remotely during earlier research. The workflow appendix provides representative instructions, consequential outputs, failed approaches, tool problems and responses. Any eventual human authors remain responsible for final authorship, review, licensing and submission decisions.

## Artifact Availability Statement

A local reproducibility archive accompanies the prepared manuscript. It includes manuscript/process sources, the mathematical specification and benchmark notes, unchanged original and independent exact-rational checking code and outputs, global price certificates, symbolic Wolfram code and execution receipts, a selective provenance/source map, a SHA-256 manifest, and instructions for a portable Python standard-library reproduction run. The prepared DOCX contains editable Office Math, and the PDF has been rendered for page inspection. Third-party literature fulltexts, the third-party official template, credentials, unrelated files and unneeded personal absolute paths are excluded. No public repository or artifact URL has been created or verified. Public release and licensing remain separate author decisions; no upload or submission has occurred.

## Future Portal-Only Fields

The live portal was not accessed during this task. Confirm its actual required fields, abstract/keyword limits, contribution-disclosure and artifact-availability form wording, anonymization controls and permitted file types at submission time. Author identities, affiliations, contact/corresponding-author information, author order, conflicts, ORCIDs, declarations and submission-category selections must come from the actual authors and observed portal requirements. They have not been invented or populated here. Any required human review/approval must occur before being declared. These submission actions are outside local package production.
