# Relevant seed benchmark, transcription and timing diagnostic

22 October 2026. Producer reconstruction for independent review. A discrepancy below is provisional and must not be described in a manuscript as an established published-paper error until independently checked.

## Source and inspected regions

Gao, Yi, Meilin Gu and Dengpan Liu (2025), *Behind Privacy Labels: Data Tracking and Advertising Competition on App Platforms*, MIS Quarterly 49(4), 1595-1626, DOI 10.25300/MISQ/2024/17880. The supplied filename says 2026; the DOI contains 2024; neither changes the published issue year 2025.

Authoritative input: `03_Tasks/T004_contribution_model/inputs/014_Gao et al. 2026 - Data Tracking and Advertising Competition - MISQ.pdf`, SHA-256 `3912722879922010ca77ff0c934a433e7679c8d79bc3957117ac04b56ac0dc60`.

Central original regions visually inspected using the PDF skill:

* PDF p.9 / journal 1603: app/platform advertising accounting, developer objective and visible-label permission utility.
* PDF p.10 / 1604: opt-out advertising expressions and **Figure 3**, including the platform's tracking timing omitted from the adjacent prose summary.
* PDF p.12 / 1606: low-type tracking demand and Lemma 2 formula.
* PDF p.27 / 1621: Proof of Lemma 2, conditional equilibrium prices and substitution before tracking optimization.

Full relevant Markdown contexts read: PDF pp.7-14 and 26-28. Original images are preserved in `tmp/T004/seed-09.png`, `seed-10.png`, `seed-12.png`, `seed-27.png`. Page 11 was rendered by the bounded page-range command but not visually inspected or treated as a transcription receipt. This was inspection of critical equations, not a routine extraction audit.

## Terminology and platform timing

The seed calls its default-tracking, common-perception benchmark **opt-in (I)**. Users purchase on common perceived tracking, then learn actual tracking and may stop use; the app price is sunk in the continuation decision. It calls the visible-label, explicit-permission case **opt-out (O)**. Under O, purchase and app permission are chosen jointly; refusal does not prevent app use. These names should always be explained, because they can be confused with ordinary usage of the terms.

Figure 3 explicitly puts **both policy and platform tracking `t_S` in Stage 0**, before developers' Stage-1 choices. Developers make simultaneous decisions regarding app tracking and app prices in Stage 1; consumers choose in Stage 2. Thus an analysis of the platform's total payoff as a function of `t_S` should account for subsequent developer responses. It is not a contemporaneous platform/developer tracking game. The new model avoids inheriting any ambiguity by fixing platform capacity and spelling out its different architecture-then-price sequence.

## Relevant primitive reconstruction

Let `k=1-gamma`, `m=1-alpha`, and `r=xi*[1-(1-f)t_S]`. Here alpha is the high-privacy-type fraction. The low type has privacy sensitivity `lambda`, and the high type `lambda_H>lambda`. User location x is uniform on [0,1]; apps are at endpoints with transport coefficient tau. Under O, user utility for app i is

`v-tau*d_i(x)-p_i+max(0,beta-lambda_j*t_i)`.

In the central interior region `lambda*t_i<beta<lambda_H*t_i`, only low types allow app tracking. With both types' app demands interior,

`D_i = 1/2 + [p_j-p_i+m*lambda*(t_j-t_i)]/(2*tau)`,

`D_iT = m*[1/2+(p_j-p_i+lambda*(t_j-t_i))/(2*tau)]`.

App profit is `pi_i=k*p_i*D_i+r*t_i*D_iT`. The platform targets all app users regardless of app permission, earning

`Pi_S=gamma*sum_i p_i*D_i+xi*t_S*[1-f*sum_i t_i*D_iT]`.

These formulas follow from consumers' utility and first-successful-impression accounting, and reproduce the inspected seed expressions in the relevant region. Outside it, permission indicators and clipped type-specific demands must be recalculated. The formula does not describe all possible consent regimes.

For context, in regime I the purchase demand has only the price difference because perceived tracking is common. Continued usage is the privacy-type-weighted sum of `min(max((v+beta-lambda_j*t_i)/tau,0),D_i)` for each developer's distance from its endpoint. Replacing D_iT by this usage audience recovers the same advertising reach formula. We do not reproduce the seed's entire I equilibrium or its policy-ranking thresholds; neither is required for the new conditional-scope comparison.

## Simultaneous-choice stationary conditions versus the reported formula

Holding the rival's **both** choices fixed, the two own derivatives at a symmetric interior candidate satisfy

`k*p=k*tau-r*m*t`,

`r*tau-k*lambda*p-r*lambda*t=0`.

Therefore the simultaneous-choice stationary candidate is

`t_sim=tau*(r-k*lambda)/(alpha*r*lambda)`,

`p_sim=tau-r*m*t_sim/k`.

This is only a stationary candidate; positivity, tracking bounds, type-demand corners, permission changes, Hessian/global deviations and platform choice still have to be checked before calling it an equilibrium. We do not do so or use it as an accepted substitute for the seed.

By contrast, the visually inspected Lemma 2 reports

`t_reported=2*tau*(1/lambda-k/r)/(3*alpha)`,

`p_reported=tau-r*m*t_reported/k`.

The appendix first solves the conditional price game:

`p_A=tau + m*[-r*(2*t_A+t_B)-k*lambda*(t_A-t_B)]/(3*k)`,

`p_B=tau - m*[r*(t_A+2*t_B)-k*lambda*(t_A-t_B)]/(3*k)`,

then states that both prices are substituted into developers' profits to derive tracking. This procedure differentiates along the rival's conditional price response, which is appropriate to a price-after-tracking continuation, but differs from a simultaneous choice of price and tracking as stated in Figure 3. We have not independently established that the complete reported expression is a global equilibrium under an alternative timing; the diagnosis is specifically a discrepancy with the displayed simultaneous-choice primitives.

Substituting the reported pair into the own tracking derivative of the simultaneous-choice profit yields

`d pi_i/d t_i = (1-alpha)*(r-k*lambda)/6`.

It is positive whenever the reported interior tracking level is positive. This symbolic residual was calculated in the Wolfram evaluator (15.0.1) and independently embodied in exact rational Python calculations. A nonzero residual is consequential only when a feasible same-regime deviation exists; the following example supplies one.

## Feasible deviation witness

Set `alpha=1/2`, `lambda=1`, `lambda_H=2`, `beta=2/5`, `tau=1`, `gamma=1/5`, and `r=1`. One realization is `f=1/2`, `t_S=4/5`, `xi=5/3`. Choose `v=3`, ensuring full app coverage at the specified prices. The reported pair is `t=4/15`, `p=5/6`.

Raise own tracking alone by `epsilon=1/100`, to `83/300`, holding both prices and the rival's tracking fixed. Both old and deviating tracking are strictly in `(0,1)`, low types still strictly consent, high types strictly refuse, and both type-specific app demands remain strictly interior. In particular `83/300<2/5<8/15`; the right inequality uses the rival's high-type cost, and the deviator's is larger. The common-price low-type share changes from 1/2 to .495; high-type share stays 1/2. Full coverage remains slack.

Developer profit increases from `2/5` to `48017/120000`, a gain of `17/120000` (approximately .0001416667). The own derivative at the reported pair is `1/60`. This is an exact feasible unilateral deviation against the simultaneous-choice interpretation, not a numerical optimizer or grid result. It says nothing by itself about the seed's broader qualitative findings or every alternative interpretation.

## Implication for the current model

The new model uses the inherited Hotelling/commission/first-impression accounting but makes its own timing explicit: public binary architecture commitment followed by a price subgame and joint user permission. That sequencing is also consistent with the general privacy-then-price foundation in Casadesus-Masanell and Hervas-Drane (2015, inspected PDF pp.9-10). It is an intentional new primitive, not a silent correction of Gao.

The current contribution does not depend on the discrepancy, on the seed's I-versus-O policy ranking or on a claim to replicate Lemma 2. In its separable-privacy limit (`kappa=0`), E and J coincide internally, but the model still does not nest Gao's two-type continuous-tracking equilibrium. A future manuscript can explain the model mapping without accusing the seed of an error. Independent review must decide whether to retain the timing diagnostic in research notes only or require further treatment.

Evidence: `10_Analysis/T004_feasibility.py`, `10_Analysis/T004_results.json` (seed section), `10_Analysis/T004_checks.wl`, `10_Analysis/T004_evidence/wolfram_receipt.json`, and original-page render paths above.
