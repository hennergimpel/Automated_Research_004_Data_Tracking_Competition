# Complete model and producer derivations

Version T004, 22 October 2026. Related game building on Gao, Gu and Liu, not a nesting claim. All results below are producer derivations awaiting independent review.

## 1. Economic environment and timing

There is a platform S, two app developers A and B at locations 0 and 1, and a unit mass of atomless consumers `(x,z)`, independently uniform on `[0,1] x [0,L]`. Location is app taste; `z` is the net standalone value of platform personalization enabled by its data permission. Developers know the distribution, not individual types; consumers know their own type and all announced choices. All distributions and primitives are common knowledge. There is no private seller signal, price discrimination or contracting on permission.

An exogenous policy `g in {E,J}` is fixed before play. Under E, platform data use is exempt and its permission indicator is fixed to one; users may still refuse app tracking. Under J, users can independently choose permission for each controller. Accurate app information and available architectures are identical under the policies. The platform's targeting intensity `s` is fixed. Its policy preference is a payoff comparison, not a platform optimization stage. This isolates scope rather than jointly changing label information, defaults and capacity.

1. Developers simultaneously choose a publicly observable, binding architecture `t_i in {t_L,t_H}`, where `0<t_L<t_H<1`. These are two technologically available designs, not a discretization used to approximate an unobserved continuous action set. Architecture determines conditional app targeting success and privacy exposure.
2. After observing both architectures, developers simultaneously choose `p_i in [0,P]`. The upper bound is a mathematical compact-domain restriction. It is slack in the result; additionally, the reported candidate withstands all unbounded nonnegative price deviations given its rival. No claim is made that actual stores impose this particular bound.
3. Consumers jointly choose A, B, platform-only use, or no participation, and the available permission pair `(phi_i,phi_S) in {0,1}^2`. Permission is informed, free to refuse and enforceable for the period. Price is paid only on app purchase. There is no sunk-price abandonment stage and no switching cost.
4. Conditional on permission, app and platform targeting successes are independent Bernoulli events with probabilities `t_i` and `s`. The app is visited first with probability `f`, independent of types, permissions and targeting success. Only the first successful relevant impression earns `xi`; later impressions earn zero. If there is no app purchase, the platform alone can target a permitting platform user. Advertisers are represented by this fixed payment technology, not strategic players.

All main equilibria fully cover the app market. Off-path choices and participation remain defined. Developers maximize expected revenue, with zero production/data costs. The equilibrium concept is pure-strategy subgame-perfect equilibrium of stages 1-3 conditional on policy. Mixed architecture strategies can also be defined; strict dominance in the illustrated reduced games excludes them when using the unique pure price continuations. We do not assert uniqueness among arbitrary mixed-strategy price continuations.

## 2. Utility, permissions and domains

For app i at distance `d_i(x)`, user utility is

`U_i = v - tau*d_i(x) - p_i + (B-lambda*t_i)*phi_i + z*phi_S - kappa*t_i*phi_i*phi_S`.

Platform-only utility is `z*phi_S` and no participation gives zero. Under E, `phi_S=1`; under J it is chosen. Since `z>=0`, platform-only value is `z` in either policy. The incremental loss `kappa*t_i` when both controllers have permission is a primitive representing complementary privacy exposure. It is not double-counted as a loss from ad impressions, and no actual cross-controller data transfer is assumed. The coefficient includes the fixed platform technology's exposure scale; changing `s` while holding `kappa` fixed is outside the interpretation used here.

Parameter domain: `tau,L,xi,v,B>0`, `lambda>=0`, `kappa>=0`, `0<s<=1`, `0<=f<=1`, `0<=gamma<1`, `k=1-gamma>0`, and `P>0`. For the central result impose `0<kappa*t_L<kappa*t_H<L`, `0<a=(1-f)s<1`, `B>(lambda+kappa)*t_H` and `v-P-tau+B-(lambda+kappa)*t_H>0`.

These last conditions imply, for every available architecture and every price history:

* App permission strictly dominates its refusal holding platform permission fixed: its incremental benefit is at least `B-(lambda+kappa)t_H>0`. Thus `phi_i=1` is derived, not imposed.
* With J, `phi_S=1` iff `z>=kappa*t_i`; with E, `phi_S=1`. Ties at the threshold have measure zero; set permission to one there. The user can allow both, only the app, or neither by choice, though some bundles are dominated in this restricted domain.
* At least one app, indeed each app even at maximum distance and price, dominates platform-only use. Therefore full coverage holds for every history, not merely the candidate equilibrium.

Write app non-price utility excluding v and distance as `B+w_g(t,z)`. Then

`w_E(t,z)=-(lambda+kappa)t+z`,

`w_J(t,z)=-lambda*t+max(0,z-kappa*t)`.

The common standalone platform term cancels from app comparison, but the *interaction* does not: app architecture changes the optimally chosen platform permission. This directly addresses the common-privacy-cost cancellation objection. If `kappa=0`, the policies coincide (apart from zero-measure ties), as verified in code.

## 3. Audience and profit accounting

For any prices and architectures, the fraction of type-z consumers using i is

`d_i(z)=clip((tau+p_j-p_i+w_g(t_i,z)-w_g(t_j,z))/(2*tau),0,1)`.

Actual app audience `D_i=E[d_i]`. Let `b_i(z)` be platform permission among users choosing i, equal to one under E and `1{z>=kappa*t_i}` under J. Conditional app advertising revenue per user is

`r_i(z)=xi*t_i*[1-(1-f)*s*b_i(z)]`.

Conditional platform revenue per such user is `xi*s*b_i(z)*(1-f*t_i)`. These follow by separately enumerating app-first and platform-first events. No independence of permissions is assumed: the underlying joint permission is derived from the utility problem. Here app permission is one, so the joint moment equals platform permission conditional on chosen app; actual audience-weighted overlap is `E[d_i(z)b_i(z)]`, not generally `D_i*E[b_i]` when architectures differ.

`pi_i=E[(k*p_i+r_i(z))*d_i(z)]`,

`Pi_S=gamma*(p_A*D_A+p_B*D_B)+xi*s*sum_i E[d_i(z)b_i(z)(1-f*t_i)]`.

No fees are paid for denied targeting. Price commissions are transfers between developer and platform. Advertiser payments are outside the modeled utility system; summing the displayed profits and user utility is not a complete social-welfare measure. We do not report one.

## 4. Conditional price lemma and global checks

For fixed architectures define `W_i=E[w_i]`, `R_i=E[r_i]`, `C_i=E[r_i*(w_i-w_j)]`. If every type's app share is interior, direct integration gives

`pi_i=k*p_i*[1/2+(p_j-p_i+W_i-W_j)/(2*tau)] + R_i*[1/2+(p_j-p_i)/(2*tau)] + C_i/(2*tau)`.

The first-order equations give

`p_i=tau+(W_i-W_j)/3-(2*R_i+R_j)/(3*k)`.

Put `H_i=W_i+R_i/k`, `DeltaH=H_i-H_j`. Then

`D_i=1/2+DeltaH/(6*tau)`,

`pi_i=k*tau/2+k*DeltaH/3+k*DeltaH^2/(18*tau)+Cov(r_i,w_i-w_j)/(2*tau)`.

The covariance term is essential under J. A revenue calculation that replaces every audience by half or multiplies marginal permission rates without sorting would miss it. Wolfram independently simplifies the price FOC residual and profit identity to zero; this checks algebra, not equilibrium.

Here are sufficient global conditions that make this price solution the unique **pure** price equilibrium for every architecture pair. Let `d=(lambda+kappa)*(t_H-t_L)` and `rmax=xi*t_H`. Require

`tau>3*d`,

`k*(1-d/tau) - [k*max(0,P-tau+d)+rmax]/(2*tau)>0`,

`(tau-d-rmax/k)/2>0`, and `(tau+P+d)/2<P`.

Proof: `|w_i-w_j|<=d`. At prices below `p_j-tau+d`, own demand is at least `1-d/tau`; where differentiable, the price derivative is bounded below by the second displayed inequality. Below the range with any clipping it is simply positive. At prices above `p_j+tau-d`, there are no fully captured types; each active type's share is at most `d/tau`, so the derivative is negative whenever demand is positive because `p_i>=tau-d>2d`. Zero demand cannot maximize against a positive-profit alternative. Thus a best response lies where all type shares are interior. There profit is a strictly concave quadratic in own price, and its unique unconstrained maximizer is `(tau+p_j+W_i-W_j-R_i/k)/2`. The final two inequalities keep it strictly in `[0,P]`. Best replies have slope 1/2, yielding a unique intersection. Breakpoint one-sided derivatives preserve these arguments. The proof covers clipping and price boundaries, not just FOCs.

For the rational example, the executable script checks these strict sufficient inequalities. It also integrates all clipped demands exactly and certifies, independently of this lemma's argument, that the reported price yields no less profit than **any** nonnegative price. In each structural price interval the gap is a polynomial of degree at most three; nonnegative rational Bernstein coefficients prove nonnegativity on the entire interval. Structural breakpoints, the equilibrium price, zero and the zero-demand threshold are included; rational subdivision is used only if a coefficient test needs refinement. Beyond the zero-demand threshold profit is zero. This is an exact piecewise certificate, not a finite deviation grid. The Bernstein certificates and intervals are saved in `10_Analysis/T004_evidence/price_certificates.json`.

## 5. Architecture game and analytic discriminator

For symmetric architectures the covariance is zero and each developer earns `k*tau/2`. Hence only the two off-diagonal profits are needed to determine the reduced two-action game. At a general point satisfying the price lemma, high is strictly dominant if `pi_H(H,L)>k*tau/2` and `pi_L(L,H)<k*tau/2`; low is strictly dominant if both inequalities reverse. This exhausts design deviations because the action set has exactly two architectures.

For `h>l`, the utility and advertising-margin differences are

`DeltaW_E=-(lambda+kappa)*(h-l)`,

`DeltaR_E=xi*(1-a)*(h-l)`,

`DeltaW_J=-(lambda+kappa)*(h-l)+kappa^2*(h^2-l^2)/(2*L)`,

`DeltaR_J=xi*(1-a)*(h-l)+xi*a*kappa*(h^2-l^2)/L`.

Consequently

`DeltaH_J-DeltaH_E=(h^2-l^2)*[kappa^2/(2*L)+xi*a*kappa/(k*L)]>0`.

The first term is the relief from platform privacy exposure when users can refuse; the second is the developer's incremental advertising advantage from those refusals. It is the second term, together with endogenous sorting, that distinguishes the advertising-competition mechanism from simply lowering a common privacy cost.

For the high developer in the off-diagonal J profile,

`Cov(r_H,w_H-w_L)=xi*a*h*kappa^2*(h^2-l^2)*(1-kappa*h/L)/(2*L)>0`.

For the low developer,

`Cov(r_L,w_L-w_H)=-xi*a*l*(kappa*l/L)*kappa*(h-l)*[1-kappa*(h+l)/(2*L)]<0`.

These formulas follow by splitting z at `kappa*l` and `kappa*h`; the first is symbolically checked and both are computed by exact integration. The covariance makes the high architecture's price-induced audience composition more favorable and the low architecture's less favorable.

For a sharper constant-capacity diagnostic, set `qmid=1-kappa*(h+l)/(2*L)`. A constant platform capacity matching that average permission rate gives `DeltaR_fit=xi*(h-l)*(1-a*qmid)`. Keep **the actual** `DeltaW_J`, so the fit is not disadvantaged by an incorrect average privacy burden. Nevertheless

`DeltaH_J-[DeltaW_J+DeltaR_fit/k]=xi*a*kappa*(h^2-l^2)/(2*k*L)>0`.

At the example the fit predicts a negative competitive index, while the actual index is positive. This is a falsification of a constant substitution, not a claim that arbitrary exogenous consent is a realistic alternative policy. The joint distribution in the actual game always follows the explicit user choice.

## 6. Exact existence example

Use `tau=2`, `L=B=1`, `v=10`, `P=3`, `gamma=1/5`, `xi=11/20`, `s=4/5`, `f=1/2`, `lambda=1/10`, `kappa=4/5`, `t_L=1/4`, `t_H=3/4`.

| Policy/profile | p_A | p_B | A share | A profit | Platform profit |
|---|---:|---:|---:|---:|---:|
| E, LL | 1.896875 | 1.896875 | .5000000 | .8000000000 | .7643750000 |
| E, HL | 1.609375 | 1.978125 | .4796875 | .7363203125 | .6924824219 |
| E, LH | 1.978125 | 1.609375 | .5203125 | .8663203125 | .6924824219 |
| E, HH | 1.690625 | 1.690625 | .5000000 | .8000000000 | .6131250000 |
| J, LL | 1.883125 | 1.883125 | .5000000 | .8000000000 | .6846250000 |
| J, HL | 1.575625 | 1.874375 | .5021875 | .8096553125 | .5536561719 |
| J, LH | 1.874375 | 1.575625 | .4978125 | .7923553125 | .5536561719 |
| J, HH | 1.566875 | 1.566875 | .5000000 | .8000000000 | .4233750000 |

Therefore E has LL and J has HH as the unique pure architecture equilibria with the pure price continuations. User permission is not at a knife edge: under J a fraction .8 of consumers permits the platform at LL and .4 at HH. App permission is strict everywhere. Both architectures and all prices are interior to their numerical ranges where applicable. Every strict inequality varies continuously with primitives, so the contrast persists in a nonempty open neighborhood; an explicit maximal neighborhood is not claimed. The results file preserves exact fractions; displayed decimals are explanatory.

## 7. Remaining derivation and review obligations

1. Independently rederive the utility envelope, audience accounting, covariance identities, global price lemma and architecture inequalities. Verify the Bernstein certificate logic; a tool's successful output is not independent acceptance.
2. Decide whether the narrow existence result plus analytic index decomposition is a meaningful contribution relative to the closest consent and privacy-competition models. Reject if it is only a renamed existing mechanism.
3. Resolve the provisional seed timing/FOC discrepancy before any claim about the original paper's validity. The new-game result does not rely on correcting the seed.
4. For writing, state one general conditional price lemma and one strict existence/architecture-contrast proposition with compact proofs. An explicit robustness interval would be useful but is not needed to establish the open-set argument. Continuous tracking, low app-benefit regions, endogenous capacity, unbounded-price equilibrium uniqueness and mixed price equilibria are outside the established result.
5. Do not claim that a platform would adopt J voluntarily in the example: its profit is lower. Do not infer a regulatory recommendation from developer tracking alone or relabel aggregate impression revenue as social welfare.
