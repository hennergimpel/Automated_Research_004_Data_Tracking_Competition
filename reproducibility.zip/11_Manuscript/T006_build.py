"""Build the manuscript in the retained official Word package.

Python 3.11+, lxml and Pandoc 3.2. PDF export uses the separate Word helper.
No mathematical output or original template is changed by this builder.
"""
from pathlib import Path
import argparse, copy, hashlib, json, shutil, subprocess, zipfile
from lxml import etree as E

ROOT = Path(__file__).resolve().parents[1]
SUPPORT = ROOT / '11_Manuscript/T006_support'
RENDER = ROOT / '13_Export/T006_render'
NS = {'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
      'm':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
W = '{'+NS['w']+'}'
TITLE = 'Platform Permission and App Tracking: Advertising Competition with Complementary Privacy Exposure'
SHORT = 'Platform Permission and App Tracking'

def sha(data): return hashlib.sha256(data).hexdigest()
def xml(r): return E.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)
def ptext(p): return ''.join(p.xpath('.//w:t/text()',namespaces=NS))
def style(p,name):
    pr=p.find(W+'pPr')
    if pr is None: pr=E.Element(W+'pPr'); p.insert(0,pr)
    s=pr.find(W+'pStyle')
    if s is None: s=E.Element(W+'pStyle'); pr.insert(0,s)
    s.set(W+'val',name)
    return pr

def build(pandoc, template=None):
    SUPPORT.mkdir(parents=True,exist_ok=True); RENDER.mkdir(parents=True,exist_ok=True)
    source=Path(template) if template else ROOT/'03_Tasks/T006_manuscript_package/inputs/028_official_template.docx'
    if not source.exists(): source=SUPPORT/'official_template.docx'
    if not source.exists(): raise FileNotFoundError('Provide --template or T006_support/official_template.docx')
    paper=(ROOT/'11_Manuscript/T006_paper.md').read_text(encoding='utf-8')
    appendix=(ROOT/'11_Manuscript/T006_workflow_appendix.md').read_text(encoding='utf-8')
    merged=SUPPORT/'assembled.md'; merged.write_text(paper+'\n\n'+appendix,encoding='utf-8')
    fragment=SUPPORT/'pandoc_body.docx'
    version=subprocess.check_output([pandoc,'--version'],text=True).splitlines()[0]
    subprocess.run([pandoc,str(merged),'-f','markdown+tex_math_dollars-autolink_bare_uris',
                    '-t','docx','-o',str(fragment)],check=True)
    out=ROOT/'13_Export/paper.docx'
    with zipfile.ZipFile(source) as src, zipfile.ZipFile(fragment) as frag:
        parts={n:src.read(n) for n in src.namelist()}
        root=E.fromstring(parts['word/document.xml']); body=root.find('w:body',NS)
        section=copy.deepcopy(body.find('w:sectPr',NS))
        assert section is not None
        for ch in list(body): body.remove(ch)
        froot=E.fromstring(frag.read('word/document.xml'))
        inrefs=False; inappendix=False
        incoming=list(froot.find('w:body',NS))
        for idx,ch in enumerate(incoming):
            if ch.tag==W+'sectPr': continue
            ch=copy.deepcopy(ch)
            if ch.tag==W+'p':
                s=ch.find('w:pPr/w:pStyle',NS); sty=s.get(W+'val') if s is not None else ''
                txt=ptext(ch)
                if txt==TITLE: style(ch,'Title')
                elif txt.startswith('Workflow Appendix:'):
                    inappendix=True; inrefs=False
                    E.SubElement(style(ch,'Heading1'),W+'pageBreakBefore')
                elif txt=='References':
                    inrefs=True; E.SubElement(style(ch,'Heading1'),W+'pageBreakBefore')
                elif sty=='Heading2': style(ch,'Heading1' if not inappendix else 'Heading2')
                elif sty=='Heading3': style(ch,'Heading2')
                elif inrefs: style(ch,'References')
                elif txt.startswith(('Table 1.','Table 2.')):
                    E.SubElement(style(ch,'Caption'),W+'keepNext').set(W+'val','0')
                else: style(ch,'Normal')
                # Keep adjacent display equations together, including the two-line witness.
                next_is_math=(idx+1<len(incoming) and incoming[idx+1].find('m:oMathPara',NS) is not None)
                if next_is_math and (ch.find('m:oMathPara',NS) is not None or txt=='Proof. Consider the rational point'):
                    E.SubElement(ch.find(W+'pPr'),W+'keepNext')
                applied=ch.find('w:pPr/w:pStyle',NS).get(W+'val')
                if applied in ('Heading1','Heading2'):
                    pr=ch.find(W+'pPr'); jc=pr.find(W+'jc')
                    if jc is None: jc=E.SubElement(pr,W+'jc')
                    jc.set(W+'val','left')
            for s in ch.xpath('.//w:rStyle',namespaces=NS): s.getparent().remove(s)
            # Retain DOI text while avoiding fragment-only relationship IDs.
            for link in ch.xpath('.//w:hyperlink',namespaces=NS):
                parent=link.getparent(); loc=parent.index(link)
                for child in list(link): parent.insert(loc,child); loc+=1
                parent.remove(link)
            for tbl in ch.xpath('self::w:tbl | .//w:tbl',namespaces=NS):
                pr=tbl.find(W+'tblPr')
                if pr is None: pr=E.Element(W+'tblPr'); tbl.insert(0,pr)
                for old in pr.findall(W+'tblStyle'): pr.remove(old)
                width=pr.find(W+'tblW')
                if width is None: width=E.SubElement(pr,W+'tblW')
                width.set(W+'w','9360'); width.set(W+'type','dxa')
                borders=E.SubElement(pr,W+'tblBorders')
                for edge in ('top','bottom','insideH'):
                    ed=E.SubElement(borders,W+edge); ed.set(W+'val','single'); ed.set(W+'sz','4'); ed.set(W+'color','808080')
                for index,row in enumerate(tbl.findall(W+'tr')):
                    trpr=row.find(W+'trPr')
                    if trpr is None: trpr=E.Element(W+'trPr'); row.insert(0,trpr)
                    E.SubElement(trpr,W+'cantSplit')
                    if index==0: E.SubElement(trpr,W+'tblHeader')
                    for col,cell in enumerate(row.findall(W+'tc')):
                        for p in cell.findall('.//'+W+'p'):
                            pp=style(p,'Normal'); jc=pp.find(W+'jc')
                            if jc is None: jc=E.SubElement(pp,W+'jc')
                            jc.set(W+'val','left' if col==0 or inappendix else 'center')
            body.append(ch)
        body.append(section)
        parts['word/document.xml']=xml(root)
        # All running-title slots use the current anonymous short title.
        for name,data in list(parts.items()):
            if name.startswith('word/header') and name.endswith('.xml'):
                h=E.fromstring(data); ts=h.findall('.//'+W+'t')
                if ts:
                    ts[0].text=SHORT
                    for t in ts[1:]: t.text=''
                    parts[name]=xml(h)
        # Only the active default footer is rendered (no evenAndOddHeaders or titlePg).
        # Other historical footer patterns remain preserved as opaque template parts.
        core=E.fromstring(parts['docProps/core.xml'])
        for elem in core:
            local=E.QName(elem).localname
            if local in ('creator','lastModifiedBy','description','subject','keywords'): elem.text=''
            elif local=='title': elem.text=TITLE
        parts['docProps/core.xml']=xml(core)
        if 'docProps/custom.xml' in parts:
            cust=E.fromstring(parts['docProps/custom.xml'])
            for elem in list(cust): cust.remove(elem)
            parts['docProps/custom.xml']=xml(cust)
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in parts.items(): z.writestr(name,data)
        assert parts['word/styles.xml']==src.read('word/styles.xml')
        assert E.tostring(section)==E.tostring(body.find('w:sectPr',NS))
        assert len(root.findall('.//w:sectPr',NS))==1
        assert not root.xpath('.//w:hyperlink | .//w:drawing',namespaces=NS)
        changed=[n for n in src.namelist() if src.read(n)!=parts[n]]
        receipt={'docx':'13_Export/paper.docx','docx_sha256':sha(out.read_bytes()),
          'template_sha256':sha(source.read_bytes()),'pandoc':version,
          'styles_sha256':sha(parts['word/styles.xml']),
          'native_styles_byte_identical':True,'section_geometry_retained':True,
          'native_omml_count':len(root.findall('.//m:oMath',NS)),
          'display_equation_count':len(root.findall('.//m:oMathPara',NS)),
          'changed_parts':changed,'anonymous_core_metadata':True,
          'abstract_present_in_body':True,'author_absent_from_body':True,
          'main_page_limit_requires_final_pdf':8}
        (SUPPORT/'assembly_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(receipt,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--pandoc',default=shutil.which('pandoc') or 'C:/Program Files/R/RStudio/resources/app/bin/quarto/bin/tools/pandoc.exe')
    p.add_argument('--template')
    a=p.parse_args(); build(a.pandoc,a.template)
