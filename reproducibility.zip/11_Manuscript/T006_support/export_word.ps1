param([Parameter(Mandatory=$true)][string]$Docx, [Parameter(Mandatory=$true)][string]$Pdf)
$ErrorActionPreference = 'Stop'
$inputPath = (Resolve-Path -LiteralPath $Docx).Path
$outputPath = [IO.Path]::GetFullPath($Pdf)
$receiptPath = $outputPath + '.receipt.json'
$before = (Get-FileHash -LiteralPath $inputPath -Algorithm SHA256).Hash.ToLowerInvariant()
$receipt = [ordered]@{started_at=[DateTimeOffset]::UtcNow.ToString('o');input=$inputPath;input_sha256=$before;renderer='Microsoft Word COM';successful=$false}
$wordInstance=$null
$wordDocument=$null
try {
  $wordInstance=New-Object -ComObject Word.Application
  $wordInstance.Visible=$false
  $wordInstance.DisplayAlerts=0
  $wordInstance.AutomationSecurity=3
  $wordDocument=$wordInstance.Documents.Open($inputPath,$false,$true,$false)
  $wordDocument.Repaginate()
  $receipt.word_version=$wordInstance.Version
  $receipt.pages=$wordDocument.ComputeStatistics(2)
  $receipt.native_equations=$wordDocument.OMaths.Count
  $wordDocument.ExportAsFixedFormat($outputPath,17,$false)
  $receipt.pdf_sha256=(Get-FileHash -LiteralPath $outputPath -Algorithm SHA256).Hash.ToLowerInvariant()
  $receipt.successful=$true
} catch { $receipt.error=$_.Exception.Message; throw }
finally {
  if($null -ne $wordDocument){$wordDocument.Close($false)}
  if($null -ne $wordInstance){$wordInstance.Quit()}
  $receipt.source_unchanged=((Get-FileHash -LiteralPath $inputPath -Algorithm SHA256).Hash.ToLowerInvariant() -eq $before)
  $receipt.ended_at=[DateTimeOffset]::UtcNow.ToString('o')
  $receipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}
$receipt | ConvertTo-Json -Depth 6
