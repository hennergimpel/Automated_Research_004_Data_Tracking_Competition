# Platform Permission and App Tracking: Advertising Competition with Complementary Privacy Exposure

**Abstract.** Can extending permission to a platform's own targeting change the tracking architectures chosen by competing app developers? We study an architecture-then-price game in which users choose an app and separate data permissions. The model assumes an additional privacy loss when both controllers use data. Strong app personalization benefits preserve app permission, while a more intensive app design induces some users to refuse the competing platform advertiser. We derive permission choices and price continuations and establish a strict existence result: platform exemption supports low tracking as a dominant architecture, whereas separate platform permission supports high tracking, on a nonempty open set of primitives. Matching aggregate platform reach with a constant targeting reduction misses the direction of the competitive index at the example. The contribution identifies a controller-specific audience response in platform governance; it does not establish a general tracking, welfare or optimal-policy effect.

## Introduction

App platforms govern access to users while also competing with developers for advertising attention. A rule allowing refusal of developer tracking can therefore leave another advertising outlet, the platform itself, outside the permission boundary. Extending that boundary changes more than the quantity of data available to the platform if users assess the privacy exposure from both outlets together. An app developer may then influence permission to its advertising rival by changing its own tracking design. This possibility matters for information systems research because the consequences of a governance rule can depend on which technical actor controls a data operation, even when app information and users' ability to refuse app tracking stay fixed.

The relationship between price and privacy is already well established. Casadesus-Masanell and Hervas-Drane (2015) model firms committing to disclosure before prices and consumers choosing information provision. Kummer and Schulte (2019) document relationships among app permissions, prices and demand; requested access is not a direct measure of realized tracking. More directly, Gopal et al. (2023) show that consent can lower website prices and increase default third-party sharing in some regimes. Thus the observation that consent can coexist with more data use is not itself a contribution. Johnson et al. (2024) likewise show that opt-out can alter data-sharing incentives through the relative value of website and look-alike audiences. The unresolved relationship examined here is a developer's design changing the permission audience of the platform with which it competes for advertising, followed by app price competition.

We ask: **When can extending permission to platform targeting reverse developers' incentives over tracking architecture?** Two developers choose between public low- and high-tracking designs before setting prices. Both governance regimes provide accurate app information and app tracking refusal. One exempts platform targeting; the other permits separate refusal. A positive cross-controller privacy interaction is an explicit assumption: simultaneous exposure to app and platform data use creates an additional loss. With sufficiently strong app benefits, users continue allowing app tracking but may refuse the platform. More intensive app tracking then reduces platform permission and expands the app's opportunity to earn the first relevant advertising impression.

The resulting sociotechnical mechanism connects a technical design choice, the organizational boundary of platform permission, and optimizing user behavior. It is a theoretical implication of the assumed privacy interaction, not evidence that real users perceive it or act on it. We establish an open-set existence contrast with unique pure price continuations on a stated compact price domain. A rational example switches the dominant design from low to high tracking when platform permission becomes available. We also separate this mechanism from a constant reduction in platform reach. These results concern a related, deliberately restricted game rather than a replication of an existing platform equilibrium.

## Relationship to Platform and Privacy Research

Gao et al. (2025) provide the closest platform setting: competing apps, platform commissions, privacy labels and rivalry for the first valuable targeted impression. Their visible-label regime permits refusal of app tracking while platform targeting remains exempt. We retain Hotelling app differentiation, commissions and first-impression advertising accounting. We change privacy heterogeneity, make platform permission architecture dependent, and place two public design choices before a price subgame. The model therefore does not nest their continuous-tracking game. The contribution lies in the response of a competing controller's permission audience, rather than labels, commissions or contact order alone.

Two close comparisons sharpen this distinction. Gopal et al. (2023) let users select third-party sharing from website menus; in some static-market cases lower prices encourage greater default sharing. That is already an endogenous consent-and-price mechanism. Here an app's design affects permission to a separate platform advertiser whose successful impression can displace the app's revenue. Johnson et al. (2024) explain how blocking changes the relative importance of website and look-alike audiences and hence cross-targeting. Their tracking fraction is given in that comparison and product prices are fixed. Our architecture-dependent permission threshold instead changes both advertising margins and the composition of an app's price-sensitive audience.

Other established mechanisms define the scope. Chen and Stallaert (2014) distinguish targeting's competitive and propensity effects in advertising auctions; our fixed first-impression payment excludes auction-price adjustment. Zhu et al. (2025) endogenize advertising rates and product-price responses under targeting restrictions; those channels can matter beyond our fixed advertising value. Zhang et al. (2026), an arXiv preprint, show how targeting precision affects seller price competition and the platform's commission/advertising revenue mix without privacy-sensitive consent. That revenue mix is therefore not new here. Shulman and Geng (2019) study platform disclosure of in-app prices and heterogeneous consumer information. We hold information accurate and common, isolating permission scope rather than attention or disclosure prominence. These comparisons locate a bounded mechanism without claiming priority over all privacy-control models.

## Model and Permission Choice

A platform and two developers serve a unit mass of consumers. App A is at 0 and app B at 1 on a Hotelling line. Consumer types $(x,z)$ are independently uniform on $[0,1]\times[0,L]$. Location $x$ determines app taste, with distance cost $\tau>0$. The variable $z$ is the net standalone value of platform personalization enabled by permission. All distributions, primitives and announced actions are common knowledge; firms do not observe individual types.

An exogenous governance regime $g\in\{E,J\}$ is fixed before play. Under exemption $E$, platform permission is fixed at one. Under joint permission $J$, users choose permission separately for the app and platform. App information, the design menu and the right to refuse app tracking are identical in both regimes. The platform has fixed targeting success $s$ and does not choose policy in this game.

First, developers simultaneously commit to public architectures $t_i\in\{l,h\}$, with $0<l<h<1$. These are two available technologies, not an approximation to a continuous action set. Second, they observe both designs and simultaneously set $p_i\in[0,P]$. Third, users jointly choose A, B, platform-only use or no participation, and the available permission pair $(\phi_i,\phi_S)\in\{0,1\}^2$. Refusal is informed, free and enforceable for the period; app price is paid only upon purchase. The equilibrium concept uses pure price continuations in this architecture-then-price game.

For distance $d_i(x)$, utility from app $i$ is

$$U_i=v-\tau d_i(x)-p_i+(B-\lambda t_i)\phi_i+z\phi_S-\kappa t_i\phi_i\phi_S.$$

Platform-only utility is $z\phi_S$; nonparticipation gives zero. Here $B>0$ is the app benefit enabled by permission and $\lambda\geq0$ its direct privacy-cost coefficient. The additional loss $\kappa t_i\phi_i\phi_S$ captures **assumed complementary privacy exposure across controllers**. Joint data use may be more revealing, but no data transfer between the controllers is required or modeled. This term is not a cost per impression. Its coefficient includes the fixed platform technology's exposure scale.

We impose $L,\xi,v,P>0$, $0<s\leq1$, $0\leq f\leq1$, $0\leq\gamma<1$, and set $k=1-\gamma$, $a=(1-f)s$. The central domain satisfies

$$0<\kappa l<\kappa h<L,\quad 0<a<1,\quad B>(\lambda+\kappa)h,$$
$$v-P-\tau+B-(\lambda+\kappa)h>0.$$

**Proposition 1 (Permission and coverage).** At every architecture and price history in this domain, every app purchaser strictly permits app tracking. Platform permission is universal under $E$ and is chosen under $J$ exactly when $z\geq\kappa t_i$. Each app dominates platform-only use at every history, so the app market is covered. Excluding the common $v$, distance and $B$ terms, optimized nonprice utilities are

$$w_E(t,z)=-(\lambda+\kappa)t+z,\qquad w_J(t,z)=-\lambda t+\max\{0,z-\kappa t\}.$$

*Proof.* Holding platform permission fixed, allowing app tracking adds $B-\lambda t-\kappa t\phi_S\geq B-(\lambda+\kappa)h>0$. Given app permission, allowing the platform adds $z-\kappa t$, yielding the threshold and utility envelopes. Under $E$, subtracting the platform-only value $z$ from app utility gives at least the final strict domain bound. Under $J$, $\max\{0,z-\kappa t\}-z\geq-\kappa t$ gives the same bound. Both apps thus dominate the outside option even at the largest distance and price. Threshold ties have zero mass. ∎

The mechanism does not rely on withdrawing app consent: it is universal in the analyzed domain. If privacy exposure were separable ($\kappa=0$), both permission regimes would yield the same optimized app comparisons and advertising audiences. A platform benefit common to both apps cancels from app choice; the architecture-dependent privacy interaction does not.

## Advertising Audiences and Price Competition

Conditional on permission, app and platform targeting successes are independent Bernoulli events with probabilities $t_i$ and $s$. App-first contact occurs with probability $f$, independently of type and success. Only the first successful relevant impression earns $\xi>0$; later impressions earn zero. Advertisers are represented by this fixed payment technology. Let $b_i(z)$ denote platform permission among app $i$'s users. Then $b_i=1$ under $E$ and $b_i=\mathbf{1}\{z\geq\kappa t_i\}$ under $J$. The type-specific app share and advertising margins are

$$d_i(z)=\operatorname{clip}\!\left(\frac{\tau+p_j-p_i+w_g(t_i,z)-w_g(t_j,z)}{2\tau},0,1\right),$$
$$r_i(z)=\xi t_i[1-a b_i(z)],\qquad r_{S,i}(z)=\xi s b_i(z)(1-ft_i).$$

For example, the app succeeds first with probability $ft_i$ and succeeds after a failed platform attempt with probability $(1-f)t_i(1-sb_i)$, giving $r_i$. Define $D_i=\mathbb E[d_i]$. With zero production and data costs, developer and platform profits are

$$\pi_i=\mathbb E[(kp_i+r_i)d_i],\qquad
\Pi_S=\gamma\sum_i p_iD_i+\sum_i\mathbb E[r_{S,i}d_i].$$

The actual platform audience is $\sum_i\mathbb E[d_i b_i]$. It generally cannot be obtained by multiplying an unconditional permission rate by half the market: different designs sort users with different platform values between the apps.

For fixed architectures put $W_i=\mathbb E[w_i]$, $R_i=\mathbb E[r_i]$, $H_i=W_i+R_i/k$ and $\Delta H_i=H_i-H_j$. Write $d=(\lambda+\kappa)(h-l)$ and $r_{\max}=\xi h$.

**Lemma 1 (Unique pure price continuation).** In addition to Proposition 1's domain, suppose

$$\tau>3d,\qquad k(1-d/\tau)-\frac{k\max\{0,P-\tau+d\}+r_{\max}}{2\tau}>0,$$
$$\frac{\tau-d-r_{\max}/k}{2}>0,\qquad \frac{\tau+P+d}{2}<P.$$

For every architecture pair and either regime, the price game on $[0,P]^2$ has a unique pure equilibrium. Every type's app shares and both prices are interior. Its prices, demands and developer profits satisfy

$$p_i=\tau+\frac{W_i-W_j}{3}-\frac{2R_i+R_j}{3k},\qquad
D_i=\frac12+\frac{\Delta H_i}{6\tau},$$
$$\pi_i=\frac{k\tau}{2}+\frac{k\Delta H_i}{3}+\frac{k(\Delta H_i)^2}{18\tau}
+\frac{\operatorname{Cov}(r_i,w_i-w_j)}{2\tau}.$$

*Proof.* The utility envelopes imply $|w_i-w_j|\leq d$. For $p_i<p_j-\tau+d$, demand is at least $1-d/\tau$. Where some types are captured completely, marginal profit is bounded below by the second strict inequality above: the loss of interior demand is at most $[kp_i+r_{\max}]/(2\tau)$ and $p_i\leq\max\{0,P-\tau+d\}$. Where all types are captured, marginal profit is positive. For $p_i>p_j+\tau-d$, no type is fully captured and each active share is at most $d/\tau$. Its marginal-profit contribution is at most $kd/\tau-kp_i/(2\tau)<0$, because $p_i\geq\tau-d>2d$. Zero demand cannot maximize against a positive-profit alternative. One-sided derivatives give the same exclusions at clipping boundaries. A best response therefore lies in the region where all shares are interior.

In that region, integrating $(kp_i+r_i)d_i$ gives a strictly concave quadratic in $p_i$, with first-order equation $2p_i-p_j=\tau+W_i-W_j-R_i/k$. The last two inequalities keep its unconstrained maximizer inside $[0,P]$ for every rival price. Best replies have slope one-half and a unique intersection, giving the displayed prices and demand. At the optimum, $kp_i+R_i=2k\tau D_i$. Separating the mean and covariance in expected advertising profit yields $\pi_i=2k\tau D_i^2+\operatorname{Cov}(r_i,w_i-w_j)/(2\tau)$, which expands as stated. ∎

This is a global result on the specified compact domain, rather than a first-order-condition calculation alone. The covariance measures how advertising margins vary with type-specific utility advantages. It vanishes at symmetric designs but matters for deviations that determine architecture incentives.

## Architecture Incentives and an Open-Set Contrast

For the high design against the low design, direct integration of Proposition 1's envelopes gives

$$\Delta W_E=-(\lambda+\kappa)(h-l),\quad
\Delta R_E=\xi(1-a)(h-l),$$
$$\Delta W_J=\Delta W_E+\frac{\kappa^2(h^2-l^2)}{2L},\quad
\Delta R_J=\Delta R_E+\frac{\xi a\kappa(h^2-l^2)}{L}.$$

Thus the high design's competitive index increases by

$$\Delta H_J-\Delta H_E=(h^2-l^2)\left(\frac{\kappa^2}{2L}+\frac{\xi a\kappa}{kL}\right)>0.$$

The first component is relief from joint privacy exposure when users refuse the platform. The second is the developer's additional advertising opportunity when that rival cannot target them. This second component distinguishes the mechanism from a utility improvement alone. Audience composition also matters. Splitting the integral at $\kappa l$ and $\kappa h$ gives

$$\operatorname{Cov}(r_H,w_H-w_L)=\frac{\xi a h\kappa^2(h^2-l^2)}{2L}(1-\kappa h/L)>0,$$
$$\operatorname{Cov}(r_L,w_L-w_H)=-\frac{\xi a l\kappa^2 l(h-l)}{L}\left(1-\frac{\kappa(h+l)}{2L}\right)<0.$$

For the high app the utility disadvantage is smallest below the platform-permission thresholds, precisely where its advertising margin is highest. For the low app the sorting effect reverses. These covariances affect design-deviation profits, so an index increase by itself is not a general dominance theorem.

**Proposition 2 (Strict architecture contrast).** A nonempty open set of primitives satisfies Propositions 1 and Lemma 1 and has low tracking strictly dominant under platform exemption but high tracking strictly dominant under joint permission. With pure price continuations, the respective architecture equilibria are uniquely $(l,l)$ and $(h,h)$.

*Proof.* Consider the rational point

$$\tau=2,\ L=B=1,\ v=10,\ P=3,\ \gamma=1/5,\ \xi=11/20,$$
$$s=4/5,\ f=1/2,\ \lambda=1/10,\ \kappa=4/5,\ l=1/4,\ h=3/4.$$

App-permission and coverage slacks are $13/40$ and $213/40$. Lemma 1's four slacks, in order, are $13/20$, $363/1600$, $331/640$ and $11/40$, all positive. Its price solution therefore applies to all four design profiles under both regimes. Symmetric-design developer profit is $k\tau/2=4/5$. Substituting the integrated means and covariances into Lemma 1 gives Table 1. For instance, under $J$ the high-versus-low competitive index is $21/800$ and the two covariances are $33/3125$ and $-33/12500$; the high and low off-diagonal profits are $0.8096553125$ and $0.7923553125$.

| Regime | Gain from high against low, relative to low-low | Gain from low against high, relative to high-high |
|:---|---:|---:|
| Platform exemption ($E$) | $-8151/128000$ | $8489/128000$ |
| Joint permission ($J$) | $30897/3200000$ | $-24463/3200000$ |

Table 1. Exact unilateral architecture-deviation gains with equilibrium price continuations.

Under $E$, high loses against low and low gains against high; low is strictly dominant. Under $J$, both signs reverse, making high strictly dominant. These exhaust the binary design deviations. Every displayed domain, price and dominance inequality is strict and continuous in primitives around this point; permission thresholds remain inside $[0,L]$. Their finite intersection contains an open neighborhood with the same contrast. ∎

The example's prices lie below the cap; Table 2 gives the symmetric equilibrium outcomes. The available checking code additionally certifies every nonnegative unilateral price deviation against each reported rival price using exact piecewise cubic profit-gap certificates, including saturated demand and the zero-demand tail. This strengthens deviation evidence at the example without asserting equilibrium uniqueness on an unbounded price domain.

| Outcome | Platform exemption | Joint permission |
|:---|---:|---:|
| Each app's architecture | $1/4$ | $3/4$ |
| Each app's price | 1.896875 | 1.566875 |
| Platform permission audience | 1 | $2/5$ |
| Each developer's profit | $4/5$ | $4/5$ |
| Platform profit | 0.764375 | 0.423375 |

Table 2. Equilibrium outcomes at the rational example; decimal entries are exact terminating values.

### Why Matching Platform Reach Is Insufficient Here

A useful diagnostic holds the actual $\Delta W_J$ fixed and replaces architecture-dependent platform permission with a constant reach $q$. Its fitted index is $\Delta H_{\mathrm{fit}}=\Delta W_J+\xi(h-l)(1-aq)/k$. The arithmetic mean of the two architecture-specific marginal permission rates is $\bar q=1-\kappa(h+l)/(2L)$. At this fit,

$$\Delta H_J-\Delta H_{\mathrm{fit}}=\frac{\xi a\kappa(h^2-l^2)}{2kL}>0.$$

At the example $\bar q=3/5$ gives a fitted index of $-23/800$, versus the actual $21/800$. Sorting yields realized platform reach $4761/8000=0.595125$; matching it gives $-17971/640000$, still negative. Matching mean utility and realized reach therefore misses the index sign here. These fits are diagnostics, not feasible optimizing-user policies; they establish neither failure of all exogenous-consent models nor the full architecture game.

## Discussion

### Theoretical Contribution

The paper identifies a controller-specific permission response in a dual-role platform: an app's tracking design can reduce permission for its advertising rival and thereby improve its own advertising opportunity. The contrast is sharper than the familiar observation that consent changes prices or can increase data use, already present in Gopal et al. (2023). It also differs from the website/look-alike audience externality in Johnson et al. (2024). The mechanism makes the rival controller's audience endogenous to app architecture and carries that response into price competition and sorting. Relative to Gao et al. (2025), the contribution is a related game exposing this permission boundary, with a strict open-set contrast rather than a general extension of their equilibrium. Complementary privacy exposure is the assumed source of the response, not a separate finding.

### Theoretical Implications

Models of privacy governance should distinguish an outlet's targeting technology from its permission audience when competitors can influence that audience. A single effective platform-reach parameter may capture aggregate advertising loss while omitting design-dependent opportunity and audience composition. The diagnostic demonstrates that omission at one strict example; it does not imply that every reduced-form calibration fails. Future theory can ask whether the channel survives weaker app benefits, where an intensive design also loses app consent, or privacy interactions with another sign. Those changes alter the permission envelope central to the result. Endogenous advertising prices, as in Zhu et al. (2025), could also change the balance between lost platform reach and developers' advertising gains.

### Practical Implications

For platform designers and governance analysts, the result motivates examining which controller receives permission after an app design change, alongside headline opt-out rates. Where joint privacy exposure is perceived and app benefits keep app permission high, extending platform refusal can change developers' design incentives as well as platform reach. An assessment would need evidence on cross-controller privacy preferences, design alternatives, conditional permission and price responses; aggregate consent alone is insufficient for that mechanism. This is a diagnostic implication, not a calibrated recommendation to extend or restrict permission. The platform loses profit at the example, so voluntary adoption is not established. Developers' symmetric profits are unchanged despite higher tracking and lower prices. Neither tracking nor these transfers determines social welfare.

### Limitations

The result is an existence theorem for two available architectures, not a prediction of continuous tracking or a statement that platform permission generally increases app tracking. Strong app benefits deliberately exclude app-consent losses, and the uniform independent type distribution isolates the interaction rather than estimating it. Most importantly, positive complementary privacy exposure is assumed and has not been empirically validated. If it is absent, this model's permission contrast disappears. The compact price domain supports uniqueness only among pure price continuations; the cap is slack at the example, and global unilateral deviation certificates do not prove unbounded-domain or mixed-price uniqueness. Platform technology, commissions, contact order and advertising value are fixed. No endogenous platform policy choice, optimal regulation or complete advertiser-and-user welfare system is modeled. These boundaries limit transfer to actual app ecosystems and identify the precise mechanisms an extension would need to address.

## References

Casadesus-Masanell, R., & Hervas-Drane, A. (2015). Competing with privacy. *Management Science, 61*(1), 229–246. https://doi.org/10.1287/mnsc.2014.2023

Chen, J., & Stallaert, J. (2014). An economic analysis of online advertising using behavioral targeting. *MIS Quarterly, 38*(2), 429–449. https://doi.org/10.25300/MISQ/2014/38.2.05

Gao, Y., Gu, M., & Liu, D. (2025). Behind privacy labels: Data tracking and advertising competition on app platforms. *MIS Quarterly, 49*(4), 1595–1626. https://doi.org/10.25300/MISQ/2024/17880

Gopal, R. D., Hidaji, H., Kutlu, S. N., Patterson, R. A., & Yaraghi, N. (2023). Law, economics, and privacy: Implications of government policies on website and third-party information sharing. *Information Systems Research, 34*(4), 1375–1397. https://doi.org/10.1287/isre.2022.1178

Johnson, J. P., Jungbauer, T., & Preuss, M. (2024). Online advertising, data sharing, and consumer control. *Management Science, 70*(11), 7984–8002. https://doi.org/10.1287/mnsc.2022.03385

Kummer, M., & Schulte, P. (2019). When private information settles the bill: Money and privacy in Google's market for smartphone applications. *Management Science, 65*(8), 3470–3494. https://doi.org/10.1287/mnsc.2018.3132

Shulman, J. D., & Geng, X. (2019). Does it pay to shroud in-app purchase prices? *Information Systems Research, 30*(3), 856–871. https://doi.org/10.1287/isre.2019.0835

Zhang, Z., Kwark, Y., Raghunathan, S., & Wang, P. (2026). *Separating advertising and marketplace functions of e-commerce platforms: Is it social welfare enhancing?* (Version 2) [Preprint]. arXiv. https://doi.org/10.48550/arXiv.2502.08548

Zhu, R., Moorthy, S., & Shi, X. (2025). Advertising platforms and privacy. *Marketing Science, 44*(6), 1381–1406. https://doi.org/10.1287/mksc.2024.0879
