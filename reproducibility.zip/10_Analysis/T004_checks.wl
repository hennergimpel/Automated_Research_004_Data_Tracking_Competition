(* T004 canonical stateless Wolfram check, executed through the connector.
   Independent scientific review is still required. *)
ClearAll[t,u,z,lam,kap,ell,xi,a,k,tau,p,pj,ww,rr,rrj,cc];
ass=0<u<t<1&&0<kap*t<ell&&0<a<1&&xi>0&&k>0&&tau>0;
dw1=-lam*(t-u);dw2=dw1-(z-kap*u);dw3=-(lam+kap)*(t-u);
ew=FullSimplify[(Integrate[dw1,{z,0,kap*u}]+Integrate[dw2,{z,kap*u,kap*t}]+Integrate[dw3,{z,kap*t,ell}])/ell,ass];
er=xi*t*(1-a+a*kap*t/ell);
erj=xi*u*(1-a+a*kap*u/ell);
erdw=FullSimplify[(xi*t*Integrate[dw1,{z,0,kap*u}]+xi*t*Integrate[dw2,{z,kap*u,kap*t}]+xi*t*(1-a)*Integrate[dw3,{z,kap*t,ell}])/ell,ass];
cov=FullSimplify[erdw-er*ew,ass];
covFormula=xi*a*t*kap^2*(t^2-u^2)/(2*ell)*(1-kap*t/ell);
indexJ=ew+(er-erj)/k;indexE=(t-u)*(xi*(1-a)/k-lam-kap);
indexDelta=FullSimplify[indexJ-indexE,ass];
profit=k*p*(1/2+(pj-p+ww)/(2*tau))+rr*(1/2+(pj-p)/(2*tau))+cc/(2*tau);
price= tau+ww/3-(2*rr+rrj)/(3*k);pricej=tau-ww/3-(2*rrj+rr)/(3*k);
priceResidual=FullSimplify[D[profit,p]/.{p->price,pj->pricej}];
profitIdentity=FullSimplify[(profit/.{p->price,pj->pricej})-(k*tau/2+k*(ww+(rr-rrj)/k)/3+k*(ww+(rr-rrj)/k)^2/(18*tau)+(cc-rr*ww)/(2*tau))];
seedProfit=k*p*(tau-p+pj-(1-alpha)*lam*(t-u))/(2*tau)+r*t*(1-alpha)*(tau-p+pj-lam*(t-u))/(2*tau);
seedT=2*tau*(1/lam-k/r)/(3*alpha);seedP=tau-r*(1-alpha)*seedT/k;
seedResidual=Factor[D[seedProfit,t]/.{t->seedT,u->seedT,p->seedP,pj->seedP}];
{$Version,ew,cov,FullSimplify[cov==covFormula,ass],indexDelta,priceResidual,profitIdentity,seedResidual}
