"""T004 exact-rational feasibility for a related binary-architecture game.
Run with Python 3.11+; standard library only. No grid, optimizer or simulation.
Piecewise cubic global price-deviation bounds use rational Bernstein coefficients.
These producer calculations are evidence for independent review, not acceptance.
"""
from fractions import Fraction as Q
from math import comb
from pathlib import Path
import json, sys, platform

ROOT=Path(__file__).resolve().parents[1]
PARAMS=dict(tau=Q(2),k=Q(4,5),xi=Q(11,20),s=Q(4,5),f=Q(1,2),kap=Q(4,5),lam=Q(1,10),L=Q(1),B=Q(1),v=Q(10),P=Q(3))
TL,TH=Q(1,4),Q(3,4)
def integ(a,b,lo,hi): return a*(hi-lo)+b*(hi*hi-lo*lo)/2
def intervals(t,u,mode,par):
    p=par; kap=p['kap']; L=p['L']; a=(1-p['f'])*p['s']
    cuts=sorted({Q(0),L,kap*t,kap*u})
    vals=[]
    for lo,hi in zip(cuts,cuts[1:]):
        z=(lo+hi)/2
        if mode=='E': bi=bj=1
        elif mode=='J': bi=int(z>=kap*t);bj=int(z>=kap*u)
        else: raise ValueError(mode)
        wi=(-p['lam']*t-bi*kap*t,Q(bi))
        wj=(-p['lam']*u-bj*kap*u,Q(bj))
        ri=p['xi']*t*(1-a*bi);rj=p['xi']*u*(1-a*bj)
        vals.append((lo,hi,bi,bj,ri,rj,(wi[0]-wj[0],wi[1]-wj[1])))
    return vals
def calc(t,u,mode,par=PARAMS):
    tau,k,L=par['tau'],par['k'],par['L']; vals=intervals(t,u,mode,par)
    W=R=Rj=C=Q(0)
    for lo,hi,bi,bj,ri,rj,d in vals:
        W+=integ(*d,lo,hi)/L;R+=ri*(hi-lo)/L;Rj+=rj*(hi-lo)/L;C+=ri*integ(*d,lo,hi)/L
    pi=tau+W/3-(2*R+Rj)/(3*k);pj=tau-W/3-(2*Rj+R)/(3*k)
    D=Q(1,2)+(pj-pi+W)/(2*tau)
    profit=k*pi*D+R*(Q(1,2)+(pj-pi)/(2*tau))+C/(2*tau)
    plat=q=Q(0); bounds=[]
    for lo,hi,bi,bj,ri,rj,d in vals:
        mass=integ(Q(1,2)+(pj-pi+d[0])/(2*tau),d[1]/(2*tau),lo,hi)/L
        plat+=par['xi']*par['s']*(bi*(1-par['f']*t)*mass+bj*(1-par['f']*u)*((hi-lo)/L-mass))
        q+=bi*mass+bj*((hi-lo)/L-mass)
        bounds += [(tau+pj-pi+d[0]+d[1]*z)/(2*tau) for z in (lo,hi)]
    plat+=(1-k)*(pi*D+pj*(1-D))
    return dict(p=pi,pj=pj,D=D,profit=profit,platform=plat,q=q,R=R,Wdiff=W,covariance=C-R*W,demand_min=min(bounds),demand_max=max(bounds))
def payoff_price(pi,pj,t,u,mode,par=PARAMS):
    """Exact all-corner demand integration for any nonnegative own price."""
    tau,k,L=par['tau'],par['k'],par['L']; ans=Q(0)
    for lo,hi,bi,bj,ri,rj,(aa,bb) in intervals(t,u,mode,par):
        cuts={lo,hi}
        if bb:
            for target in (0,2*tau):
                z=(target-tau-pj+pi-aa)/bb
                if lo<z<hi:cuts.add(z)
        cuts=sorted(cuts)
        for x,y in zip(cuts,cuts[1:]):
            mid=(x+y)/2;d=(tau+pj-pi+aa+bb*mid)/(2*tau)
            if d<=0: continue
            mass=(y-x) if d>=1 else integ((tau+pj-pi+aa)/(2*tau),bb/(2*tau),x,y)
            ans+=(k*pi+ri)*mass/L
    return ans
def solve_linear(A,b):
    n=len(b);A=[list(row)+[val] for row,val in zip(A,b)]
    for i in range(n):
        j=next(j for j in range(i,n) if A[j][i]);A[i],A[j]=A[j],A[i]
        scale=A[i][i];A[i]=[x/scale for x in A[i]]
        for j in range(n):
            if j!=i:
                scale=A[j][i];A[j]=[x-scale*y for x,y in zip(A[j],A[i])]
    return [row[-1] for row in A]
def bernstein_certificate(fun,lo,hi,depth=0):
    # The price-gap polynomial has degree <=3 on each supplied structural interval.
    xs=[Q(0),Q(1,3),Q(2,3),Q(1)]
    co=solve_linear([[x**j for j in range(4)] for x in xs],[fun(lo+(hi-lo)*x) for x in xs])
    be=[sum(co[j]*Q(comb(i,j),comb(3,j)) for j in range(i+1)) for i in range(4)]
    if min(be)>=0:return [dict(lo=lo,hi=hi,bernstein_coefficients=be,depth=depth)]
    if depth==18:raise AssertionError(('certificate unresolved',lo,hi,be))
    mid=(lo+hi)/2
    return bernstein_certificate(fun,lo,mid,depth+1)+bernstein_certificate(fun,mid,hi,depth+1)
def global_price_certificate(t,u,mode,par=PARAMS):
    sol=calc(t,u,mode,par);tau=par['tau'];pj=sol['pj'];pi=sol['p']
    delta=[]
    for lo,hi,*_,(aa,bb) in intervals(t,u,mode,par):delta.extend([aa+bb*lo,aa+bb*hi])
    pmax=pj+tau+max(delta)
    cuts={Q(0),pi,pmax}
    for d in delta:
        for x in [pj+tau+d,pj-tau+d]:
            if 0<x<pmax:cuts.add(x)
    assert payoff_price(pi,pj,t,u,mode,par)==sol['profit']
    gap=lambda pp:sol['profit']-payoff_price(pp,pj,t,u,mode,par)
    proof=[];cuts=sorted(cuts)
    for lo,hi in zip(cuts,cuts[1:]):proof+=bernstein_certificate(gap,lo,hi)
    return dict(method='exact rational piecewise cubic Bernstein nonnegativity certificate',price_upper_zero_demand=pmax,beyond_upper_profit=Q(0),candidate_profit=sol['profit'],segments=proof,all_segments_nonnegative=True)
def seed_check():
    # Interior label-regime benchmark: alpha=1/2, lambdaL=1, r=1, k=4/5,tau=1.
    alpha=Q(1,2);lam=Q(1);r=Q(1);k=Q(4,5);tau=Q(1);beta=Q(2,5);lh=Q(2)
    ts=2*tau*(1/lam-k/r)/(3*alpha);ps=tau-r*(1-alpha)*ts/k
    def prof(t):
        dl=(1-alpha)*(tau-lam*(t-ts))/(2*tau)
        D=Q(1,2)-(1-alpha)*lam*(t-ts)/(2*tau)
        return k*ps*D+r*t*dl
    eps=Q(1,100)
    assert lam*(ts+eps)<beta<lh*ts and 0<ts<ts+eps<1 and ps>0
    return dict(alpha=alpha,lambda_L=lam,lambda_H=lh,beta=beta,r=r,k=k,tau=tau,reported_t=ts,reported_p=ps,own_tracking_derivative=(1-alpha)*(r-k*lam)/6,deviation_t=ts+eps,profit_before=prof(ts),profit_after=prof(ts+eps),gain=prof(ts+eps)-prof(ts),status='provisional timing discrepancy; independent rederivation required',simultaneous_stationary_t=tau*(r-k*lam)/(alpha*lam*r),note='This is a feasible local deviation, not a global equilibrium reconstruction.')
def enc(o):
    if isinstance(o,Q):return {'exact':str(o),'decimal':float(o)}
    raise TypeError(type(o))
def run():
    games={};certs={};base=PARAMS['k']*PARAMS['tau']/2
    for mode in ['E','J']:
        games[mode]={}
        for i,t in [('L',TL),('H',TH)]:
            for j,u in [('L',TL),('H',TH)]:
                key=i+j;games[mode][key]=calc(t,u,mode);certs[mode+key]=global_price_certificate(t,u,mode)
        gh=games[mode]['HL']['profit']-base;gl=games[mode]['LH']['profit']-base
        games[mode]['high_deviation_gain_from_LL']=gh;games[mode]['low_deviation_gain_from_HH']=gl
        games[mode]['strict_dominant_architecture']='H' if gh>0 and gl<0 else 'L' if gh<0 and gl>0 else 'none'
    assert games['E']['strict_dominant_architecture']=='L' and games['J']['strict_dominant_architecture']=='H'
    # A constant capacity fitted at LL fails to predict the high deviator's ad margin.
    a=(1-PARAMS['f'])*PARAMS['s'];qL=1-PARAMS['kap']*TL/PARAMS['L'];qH=1-PARAMS['kap']*TH/PARAMS['L'];qmid=(qL+qH)/2
    actual_diff=games['J']['HL']['R']-games['J']['LH']['R']
    fitted_diff=PARAMS['xi']*(TH-TL)*(1-a*qmid)
    actual_index=games['J']['HL']['Wdiff']+actual_diff/PARAMS['k']
    fit_index=games['J']['HL']['Wdiff']+fitted_diff/PARAMS['k']
    # Sufficient inequalities place every best response to any rival price in [0,P]
    # in the region with all type-specific shares strictly between zero and one.
    d=(PARAMS['lam']+PARAMS['kap'])*(TH-TL);tau=PARAMS['tau'];k=PARAMS['k'];P=PARAMS['P'];rmax=PARAMS['xi']*TH
    low_derivative_bound=k*(1-d/tau)-(k*max(Q(0),P-tau+d)+rmax)/(2*tau)
    high_slope_condition=tau-d-2*d
    br_lower=(tau-d-rmax/k)/2;br_upper=(tau+P+d)/2
    assert low_derivative_bound>0 and high_slope_condition>0 and br_lower>0 and br_upper<P
    separable=dict(PARAMS,kap=Q(0));zero_check=all(calc(t,u,'E',separable)==calc(t,u,'J',separable) for t in [TL,TH] for u in [TL,TH]);assert zero_check
    result=dict(status='producer feasibility complete; awaits independent scientific review',python=sys.version,platform=platform.platform(),packages='Python standard library only',precision='exact fractions; decimal fields presentation only',randomness='none',parameters=PARAMS,t_L=TL,t_H=TH,games=games,price_uniqueness_sufficient_bounds=dict(d=d,low_region_positive_derivative=low_derivative_bound,high_region_negative_condition=high_slope_condition,unconstrained_br_lower=br_lower,unconstrained_br_upper=br_upper,contraction_slope=Q(1,2),participation_slack=PARAMS['v']-P-tau+PARAMS['B']-(PARAMS['lam']+PARAMS['kap'])*TH),matched_reach_discriminator=dict(qL=qL,qH=qH,qmid=qmid,actual_ad_margin_difference=actual_diff,constant_capacity_ad_margin_difference=fitted_diff,actual_competitive_index_difference=actual_index,matched_utility_constant_capacity_index_difference=fit_index,status='diagnostic of constant-parameter fit, not an alternative rational-consent equilibrium'),separable_privacy_policies_identical=zero_check,seed=seed_check(),limitations=['Binary architecture menu and bounded nonbinding price domain; no claim about continuous tracking equilibrium.','Cross-controller privacy complementarity is a theoretical primitive, not empirically estimated.','No general welfare or optimal-regulator claim.','Seed discrepancy is provisional pending independent review.'])
    out=ROOT/'10_Analysis/T004_results.json';out.write_text(json.dumps(result,default=enc,indent=2)+'\n',encoding='utf-8')
    (ROOT/'10_Analysis/T004_evidence/price_certificates.json').write_text(json.dumps(certs,default=enc,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'outputs':[str(out),'10_Analysis/T004_evidence/price_certificates.json'],'strict_dominance':{m:games[m]['strict_dominant_architecture'] for m in games},'all_eight_global_price_certificates':True,'seed_deviation_gain':float(result['seed']['gain']),'matched_capacity_index':float(fit_index),'actual_index':float(actual_index)}))
if __name__=='__main__':run()
