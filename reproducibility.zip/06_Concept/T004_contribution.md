# Contribution decision: permission spillovers across competing data controllers

Prepared 22 October 2026. Producer decision for independent contribution/model review; not scientific acceptance.

## Decision and research question

Retain one substantive repair of the permission-scope direction. Study **whether giving users a separate right to refuse the platform's targeting changes developers' incentives to adopt a more intensive tracking architecture when collecting data at both outlets creates an additional privacy loss**. The new object is the response of the platform's permission audience to a developer's design, not an exogenous correlation coefficient or a smaller platform targeting parameter.

Use the related, explicitly specified game in `07_Study/T004_model.md`: two developers choose one of two public tracking architectures, then compete in prices; users jointly choose an app and permissions. Platform targeting capacity and advertising order stay fixed. Both policy alternatives display the same accurate app information and allow app tracking refusal. They differ only in whether platform targeting can also be refused. The platform has no policy-choice stage in the main result: its preference is evaluated from its resulting profit. This replaces the initial ambition to solve Gao's full adoption problem with a compact question about competitive responses to scope.

The central assumption is an incremental privacy loss `kappa*t*Phi_app*Phi_platform`. It represents complementarity in the privacy harm of exposing data to both controllers, for example because together the information is more revealing. It does **not** assert that one party sells data to the other, that real users calculate this loss, or that the two technologies have mutually exclusive legal rights. All four permission bundles are available. A positive mass optimally allows both outlets. With an app personalization benefit sufficiently large to preserve app permission, users who value platform personalization less than `kappa*t` refuse the platform. Thus increasing app tracking changes the rival outlet's audience even though it does not remove app users or app consenters.

## Concrete discriminator and bounded result

The model gives a rigorously checkable existence result, not a universal prediction. At the exact rational parameter point in the executable evidence, low tracking is strictly dominant under platform exemption, while high tracking is strictly dominant when platform permission is available. The equilibrium architecture moves from `t=1/4` to `t=3/4`. Platform consent falls from one to `2/5`, and equilibrium app prices fall from `1.896875` to `1.566875`. Both consumers and all permission decisions are optimizing in the model. The platform's profit falls from `0.764375` to `0.423375`; no general welfare conclusion follows.

The exact architecture deviation gains are:

| Policy | Choose high against low, relative to low-low | Choose low against high, relative to high-high |
|---|---:|---:|
| Platform exempt | -0.0636796875 | +0.0663203125 |
| Both controllers subject to permission | +0.0096553125 | -0.0076446875 |

All eight conditional price solutions have exact rational certificates against **every** nonnegative unilateral price deviation, including type-demand saturation and zero-demand regions. Sufficient inequalities also establish unique pure price continuation equilibria on the stated price domain. Architecture choice is binary, so checking the two alternatives exhausts design deviations. Strict inequalities give an open neighborhood with the same qualitative contrast. The producer proof and certificate require independent verification.

A constant effective-targeting substitution misses the architecture incentive. Write `a=(1-f)s`, `q(t)=1-kappa*t/L`, `W(t)=E[w(t,z)]` and `R(t)=xi*t[1-a*q(t)]`. The competitive index determining relative demand is `W(t)+R(t)/(1-gamma)`. Matching the *average* platform consent rate at the two designs, while also matching the exact average utility difference, predicts an index difference of **-0.02875**; the endogenous-permission model gives **+0.02625**. The omitted component is `xi*a*kappa*(t_H^2-t_L^2)/(2*L*(1-gamma))`. This is a diagnostic of a failed constant-parameter fit, not a second rational-consent policy or an asserted equilibrium of an exogenous-correlation model. Moreover, the covariance between advertising margins and type-specific demand shifts enters developer profit. Neither effect is a fixed subtraction from platform reach.

## Three-direction comparison

| Direction | Assessment against rejection tests | Disposition |
|---|---|---|
| Scope of platform permission | Independent exogenous permission collapses to effective targeting; aligned binary privacy types often leave developer incentives unchanged. Repair through an explicit cross-controller privacy interaction and endogenous platform refusal. The resulting design game changes sign at a feasible, globally checked example. | Retain the repaired version only, with binary architecture and stated assumptions. |
| Imperfect attention to accurate labels | A fraction informed is already close to Shulman and Geng's information-prominence model. No distinct sorting mechanism beyond effective sensitivity was established here; off-path beliefs would add substantial burden. | Reject for this paper. This is not a proof that all attention extensions are uninteresting. |
| Endogenous engagement order | Optimizing Gao's existing `f` is mechanical; adding engagement/search costs recovers Hagiu and Jullien's exposure-participation tradeoff. No separate consent-routing result has been established. | Reject for this paper. Keep `f` fixed. |

The selected mechanism uses no exclusivity contract, advertiser multihoming choice, duplicate-contact pricing result, entry decision, revenue-sharing contract, quality asymmetry or partial coverage. Binary architecture is a tractability restriction, not itself the contribution. The first-impression technology and commission mechanism are inherited from Gao; neither is claimed as new.

## Closest discourse and exact contribution boundary

* **Gao, Gu and Liu (2025), PDF pp.7-10 / 1601-1604:** gives app permission, targeting rivalry and commissions with exempt platform targeting. The present question makes permission to that rival controller a user choice responding to app architecture. However, the new game changes privacy heterogeneity, architecture domain and price/design timing. It is a related model, **not** an algebraic nesting of the seed equilibrium. `T004_benchmark.md` records a provisional timing/FOC discrepancy in the seed that must be independently resolved before any published-paper criticism.
* **Gopal et al. (2023), inspected author manuscript PDF pp.15-17, section 3.2 and Lemma 2; pp.20-21, Proposition 1:** user permission already changes prices and third-party use, potentially increasing default data sharing. Consequently, neither 'consent can raise tracking' nor 'privacy policies have unintended effects' is new. The narrower delta is strategic withdrawal of permission from the *competing platform advertiser* in response to an app's own design, with endogenous price competition and a derived controller-audience relation.
* **Johnson, Jungbauer and Preuss (2024), inspected manuscript PDF pp.14-16, Propositions 3-4:** consent externalities already change advertiser sharing and can benefit remaining tracked users. Their website/look-alike audiences and fixed product prices differ from the developer-induced platform-permission mechanism here. Do not claim the first consent externality.
* **Zhang et al. (2026), arXiv v2 PDF pp.13-16:** targeting can change seller price competition, commissions and advertising fees. That revenue mix is not our contribution. This paper isolates which controller receives permission after a strategic data-design choice. No welfare direction is imported from that preprint, whose abstract/introduction are inconsistent.
* **Casadesus-Masanell and Hervas-Drane (2015), inspected manuscript PDF pp.9-10, section 2:** price/privacy competition, committed disclosure before prices and endogenous information provision are established. This provides a timing foundation, not evidence that the new privacy interaction is empirically prevalent.
* **Zhu, Moorthy and Shi (2025), published PDF pp.6-7, section 3:** endogenous advertising prices can affect privacy comparisons. Advertising value is deliberately fixed here; the result is conditional on that boundary.
* **Chen and Stallaert (2014), PDF pp.5-7 and Proposition 2 discussion:** auction competition and match propensity are separate targeting mechanisms. The present first-impression reduced form does not cover those auction channels.
* **Kummer and Schulte (2019), inspected manuscript PDF pp.1-3:** motivates considering price and privacy access jointly; requested permissions are not actual tracking or a calibration of `kappa`.
* **Shulman and Geng (2019), inspected 2016 draft PDF pp.8-10:** supports the broad attention alternative exclusion only; do not use its old exact thresholds as current published evidence.
* **Hagiu and Jullien (2014), inspected 2013 draft PDF pp.9-11, sections 2.4-2.6:** supports the exposure-design exclusion only.

The corpus supports a bounded contribution argument, not exhaustive novelty. Gal-Or, Gal-Or and Penmetsa (2018) remains an acknowledged acquisition gap. Do not claim priority over all privacy-induced differentiation or control effects; the selected claim is limited to a developer's design changing the permission audience of its platform advertiser. If independent review finds that its exact cross-controller mechanism is a necessary comparator, acquire that specific context before novelty acceptance. Source versions and published citation metadata remain as recorded in the immutable source registry.

## Paper scope and next scientific work

An eight-page main paper can contain: question/IS positioning and closest discourse (1.5 pages); primitives and permission solution (1.5); demand, price solution and compact proofs (1.5); architecture contrast and exact illustration (1.5); discussion, implications and limitations (1.5), leaving some flexibility. References and workflow appendix are separate. The main text must include an abstract and explicit limitations. Eight to ten substantive works are available, including four configured IS-journal sources; the final writer must use them meaningfully rather than mechanically count them.

The IS contribution is about the interaction between a technical data architecture, a platform governance boundary and an optimizing user permission decision. It does not establish real-world adoption, legal compliance, aggregate welfare or the optimal reach of privacy law. Major limitations are binary architecture, a nonbinding compact price domain, high personalization benefits that keep app consent universal, and an assumed positive cross-controller privacy interaction. The last assumption is the mechanism and must be visible in the title/argument, not hidden as a technical condition.

Next: independent contribution/model and benchmark review; then a focused derivation task to turn the supplied conditional lemmas and exact existence example into a concise proposition set, verify open-neighborhood conditions, and decide whether a small robustness result is worth the page cost. No continuous-tracking or fully general policy theorem is required. No user action is needed.
