"""Deterministic portable reproduction. Python 3.11+ standard library only."""
from pathlib import Path
import hashlib,json,subprocess,sys,platform
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read('MANIFEST.json')['files']
for item in manifest:
    assert sha(ROOT/item['path'])==item['sha256'],('manifest mismatch',item['path'])
expected=read('03_Tasks/T004_contribution_model/outputs/004_T004_results.json')
expected_independent=read('provenance/original_independent_results.json')
runs=[]
for rel in ['10_Analysis/T004_feasibility.py','12_Reviews/T004_independent/check.py']:
    run=subprocess.run([sys.executable,str(ROOT/rel)],cwd=ROOT,text=True,capture_output=True)
    runs.append({'program':rel,'exit_code':run.returncode,'stdout':run.stdout.replace(str(ROOT),'<extracted_package>'),'stderr':run.stderr.replace(str(ROOT),'<extracted_package>')})
    if run.returncode:raise RuntimeError(json.dumps(runs,indent=2))
actual=read('10_Analysis/T004_results.json')
science=['parameters','t_L','t_H','games','price_uniqueness_sufficient_bounds','matched_reach_discriminator','separable_privacy_policies_identical','seed']
for key in science:assert actual[key]==expected[key],('producer mismatch',key)
actual_independent=read('12_Reviews/T004_independent/results.json')
for key in ['precision','producer_imports','games','certificate_checks','architecture_gains','strict_slacks','fit','seed']:
    assert actual_independent[key]==expected_independent[key],('independent mismatch',key)
receipt={'status':'passed','python':sys.version,'platform':platform.platform(),'precision':'exact fractions',
  'input_manifest_verified':True,'original_code_unchanged':True,'producer_scientific_results_agree':True,
  'independent_scientific_results_agree':True,'all_eight_global_price_certificates_verified':True,
  'randomness':'none','runtime_metadata_excluded_from_science_comparison':['python','runtime','platform'],
  'runs':runs,'wolfram_rerun':False,'wolfram_evidence':'Preserved original symbolic code and remote execution receipt; the portable standard-library run does not require Wolfram.'}
(ROOT/'reproduction_report.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='runs'},indent=2))
